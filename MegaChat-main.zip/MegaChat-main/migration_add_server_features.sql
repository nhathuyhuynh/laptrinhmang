-- Migration: Add server features (Discord-like functionality)
-- Run this SQL script to add support for servers, channels, members, invitations, and server messages

-- Create servers table
CREATE TABLE IF NOT EXISTS servers (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description VARCHAR(500),
    icon_url VARCHAR(500),
    owner_id BIGINT NOT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME,
    FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create channels table
CREATE TABLE IF NOT EXISTS channels (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type VARCHAR(20) NOT NULL,
    server_id BIGINT NOT NULL,
    position INT,
    created_at DATETIME NOT NULL,
    updated_at DATETIME,
    FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create server_members table
CREATE TABLE IF NOT EXISTS server_members (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    server_id BIGINT NOT NULL,
    user_id BIGINT NOT NULL,
    nickname VARCHAR(100),
    joined_at DATETIME NOT NULL,
    UNIQUE KEY unique_server_user (server_id, user_id),
    FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create server_invitations table
CREATE TABLE IF NOT EXISTS server_invitations (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    server_id BIGINT NOT NULL,
    created_by BIGINT NOT NULL,
    invite_code VARCHAR(20) NOT NULL UNIQUE,
    max_uses INT,
    uses_count INT NOT NULL DEFAULT 0,
    expires_at DATETIME,
    created_at DATETIME NOT NULL,
    FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create server_messages table
CREATE TABLE IF NOT EXISTS server_messages (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    channel_id BIGINT NOT NULL,
    sender_id BIGINT NOT NULL,
    content VARCHAR(2000) NOT NULL,
    file_url VARCHAR(500),
    file_name VARCHAR(255),
    file_type VARCHAR(100),
    file_size BIGINT,
    created_at DATETIME NOT NULL,
    edited_at DATETIME,
    is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
    FOREIGN KEY (channel_id) REFERENCES channels(id) ON DELETE CASCADE,
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create indexes for better performance
CREATE INDEX idx_channels_server_id ON channels(server_id);
CREATE INDEX idx_channels_type ON channels(type);
CREATE INDEX idx_server_members_server_id ON server_members(server_id);
CREATE INDEX idx_server_members_user_id ON server_members(user_id);
CREATE INDEX idx_server_invitations_code ON server_invitations(invite_code);
CREATE INDEX idx_server_messages_channel_id ON server_messages(channel_id);
CREATE INDEX idx_server_messages_sender_id ON server_messages(sender_id);
CREATE INDEX idx_server_messages_created_at ON server_messages(created_at);

