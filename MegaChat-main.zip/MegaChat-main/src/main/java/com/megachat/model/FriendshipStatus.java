package com.megachat.model;

public enum FriendshipStatus {
    PENDING,
    ACCEPTED,
    DECLINED
}


