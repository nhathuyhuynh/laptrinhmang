package com.megachat.model;

public enum ChannelType {
    TEXT,
    VOICE
}

