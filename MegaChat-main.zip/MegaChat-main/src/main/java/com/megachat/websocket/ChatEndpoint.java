package com.megachat.websocket;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.megachat.model.*;
import com.megachat.repository.*;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.io.IOException;
import java.util.*;
import java.util.logging.Logger;

/**
 * ChatEndpoint - WebSocket Handler cho MegaChat Web
 * Xử lý kết nối, nhắn tin real-time theo mô hình Multi Client-Server
 * Hỗ trợ gửi tin nhắn đến đúng người nhận (không broadcast)
 */
@Component
public class ChatEndpoint extends TextWebSocketHandler {
    private static final Logger logger = Logger.getLogger(ChatEndpoint.class.getName());
    
    // Quản lý sessions: Map userId -> Set<WebSocketSession> (một user có thể có nhiều tab/device)
    private static final Map<Long, Set<WebSocketSession>> userSessions = Collections.synchronizedMap(new HashMap<>());
    // Map session -> userId để tra cứu nhanh
    private static final Map<WebSocketSession, Long> sessionToUserId = Collections.synchronizedMap(new HashMap<>());
    // Lưu danh sách userId đang online
    private static final Set<Long> onlineUserIds = Collections.synchronizedSet(new HashSet<>());
    // Map channelId -> Set<userId> (users listening to channel)
    private static final Map<Long, Set<Long>> channelSubscribers = Collections.synchronizedMap(new HashMap<>());
    
    private final UserRepository userRepository;
    private final ChatMessageRepository messageRepository;
    private final FriendshipRepository friendshipRepository;
    private final ServerMessageRepository serverMessageRepository;
    private final ChannelRepository channelRepository;
    private final ServerMemberRepository serverMemberRepository;
    private final com.megachat.service.VoiceChannelService voiceChannelService;
    private final ObjectMapper objectMapper = new ObjectMapper();
    
    public ChatEndpoint(UserRepository userRepository,
                       ChatMessageRepository messageRepository,
                       FriendshipRepository friendshipRepository,
                       ServerMessageRepository serverMessageRepository,
                       ChannelRepository channelRepository,
                       ServerMemberRepository serverMemberRepository,
                       com.megachat.service.VoiceChannelService voiceChannelService) {
        this.userRepository = userRepository;
        this.messageRepository = messageRepository;
        this.friendshipRepository = friendshipRepository;
        this.serverMessageRepository = serverMessageRepository;
        this.channelRepository = channelRepository;
        this.serverMemberRepository = serverMemberRepository;
        this.voiceChannelService = voiceChannelService;
    }
    
    /**
     * Kiểm tra user có online không
     */
    public static boolean isUserOnline(Long userId) {
        return onlineUserIds.contains(userId);
    }
    
    /**
     * Lấy danh sách userId đang online
     */
    public static Set<Long> getOnlineUserIds() {
        return new HashSet<>(onlineUserIds);
    }
    
    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        logger.info("✓ WebSocket kết nối: " + session.getId());
    }
    
    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        String payload = message.getPayload();
        
        try {
            // Phân tích tin nhắn JSON hoặc plain text
            if (payload.startsWith("{")) {
                // JSON message - tin nhắn chat
                handleJsonMessage(session, payload);
            } else if (payload.startsWith("USER:")) {
                // Đăng ký userId cho session
                handleUserRegistration(session, payload);
            } else {
                logger.warning("⚠ Không nhận dạng được format: " + payload);
            }
        } catch (Exception e) {
            logger.severe("✗ Lỗi xử lý tin nhắn: " + e.getMessage());
            e.printStackTrace();
            sendError(session, "Lỗi xử lý tin nhắn: " + e.getMessage());
        }
    }
    
    /**
     * Xử lý đăng ký userId cho session
     */
    private void handleUserRegistration(WebSocketSession session, String payload) {
        try {
            String value = payload.substring(5).trim();
            Long userId = Long.parseLong(value);
            
            // Lưu mapping
            sessionToUserId.put(session, userId);
            userSessions.computeIfAbsent(userId, k -> Collections.synchronizedSet(new HashSet<>())).add(session);
            onlineUserIds.add(userId);
            
            // Clear lastSeen when user comes online
            try {
                userRepository.findById(userId).ifPresent(user -> {
                    user.setLastSeen(null); // null means currently online
                    userRepository.save(user);
                });
            } catch (Exception e) {
                logger.warning("✗ Lỗi cập nhật lastSeen: " + e.getMessage());
            }
            
            logger.info("📝 User " + userId + " đã đăng ký WebSocket (session: " + session.getId() + ")");
            
            // Gửi xác nhận
            sendMessage(session, Map.of(
                "type", "connected",
                "userId", userId,
                "message", "Kết nối WebSocket thành công"
            ));
        } catch (NumberFormatException e) {
            logger.warning("⚠ Invalid userId format: " + payload);
            sendError(session, "UserId không hợp lệ");
        }
    }
    
    /**
     * Xử lý tin nhắn JSON
     */
    private void handleJsonMessage(WebSocketSession session, String payload) throws Exception {
        Map<String, Object> messageData = objectMapper.readValue(payload, Map.class);
        String type = (String) messageData.get("type");
        
        if ("message".equals(type)) {
            handleChatMessage(session, messageData);
        } else if ("server_message".equals(type)) {
            handleServerMessage(session, messageData);
        } else if ("subscribe_channel".equals(type)) {
            handleSubscribeChannel(session, messageData);
        } else if ("unsubscribe_channel".equals(type)) {
            handleUnsubscribeChannel(session, messageData);
        } else if ("voice_join".equals(type)) {
            handleVoiceJoin(session, messageData);
        } else if ("voice_leave".equals(type)) {
            handleVoiceLeave(session, messageData);
        } else if ("voice_signal".equals(type)) {
            handleVoiceSignal(session, messageData);
        } else if ("voice_mute".equals(type)) {
            handleVoiceMute(session, messageData);
        } else if ("voice_deafen".equals(type)) {
            handleVoiceDeafen(session, messageData);
        } else if ("voice_video".equals(type)) {
            handleVoiceVideo(session, messageData);
        } else {
            logger.warning("⚠ Unknown message type: " + type);
        }
    }
    
    /**
     * Xử lý tin nhắn chat
     */
    private void handleChatMessage(WebSocketSession session, Map<String, Object> messageData) throws Exception {
        Long senderId = sessionToUserId.get(session);
        if (senderId == null) {
            sendError(session, "Bạn cần đăng ký userId trước khi gửi tin nhắn");
            return;
        }
        
        Long receiverId = getLongValue(messageData.get("receiverId"));
        String content = (String) messageData.get("content");
        String fileUrl = (String) messageData.get("fileUrl");
        String fileName = (String) messageData.get("fileName");
        String fileType = (String) messageData.get("fileType");
        Long fileSize = getLongValue(messageData.get("fileSize"));
        
        if (receiverId == null || content == null || content.trim().isEmpty()) {
            sendError(session, "Thiếu thông tin receiverId hoặc content");
            return;
        }
        
        // Kiểm tra và lưu tin nhắn
        User sender = userRepository.findById(senderId)
            .orElseThrow(() -> new Exception("Không tìm thấy người gửi"));
        User receiver = userRepository.findById(receiverId)
            .orElseThrow(() -> new Exception("Không tìm thấy người nhận"));
        
        // Kiểm tra friendship
        if (!friendshipRepository.existsAcceptedFriendship(sender, receiver)) {
            sendError(session, "Bạn chỉ có thể nhắn tin với người đã là bạn bè");
            return;
        }
        
        // Lưu tin nhắn vào database
        ChatMessage chatMessage = new ChatMessage();
        chatMessage.setSender(sender);
        chatMessage.setReceiver(receiver);
        chatMessage.setContent(content != null ? content.trim() : "");
        chatMessage.setFileUrl(fileUrl);
        chatMessage.setFileName(fileName);
        chatMessage.setFileType(fileType);
        chatMessage.setFileSize(fileSize);
        chatMessage = messageRepository.save(chatMessage);
        
        // Tạo response message
        Map<String, Object> responseMessage = new HashMap<>();
        responseMessage.put("type", "message");
        responseMessage.put("id", chatMessage.getId());
        responseMessage.put("senderId", senderId);
        responseMessage.put("receiverId", receiverId);
        responseMessage.put("content", chatMessage.getContent());
        if (chatMessage.getFileUrl() != null) {
            responseMessage.put("fileUrl", chatMessage.getFileUrl());
            responseMessage.put("fileName", chatMessage.getFileName());
            responseMessage.put("fileType", chatMessage.getFileType());
            responseMessage.put("fileSize", chatMessage.getFileSize());
        }
        responseMessage.put("createdAt", chatMessage.getCreatedAt().toString());
        
        // Gửi tin nhắn cho người gửi (xác nhận)
        sendMessage(session, responseMessage);
        
        // Gửi tin nhắn cho người nhận (nếu đang online)
        sendToUser(receiverId, responseMessage);
        
        logger.info("💬 Tin nhắn từ " + senderId + " đến " + receiverId + ": " + content.substring(0, Math.min(50, content.length())));
    }

    /**
     * Xử lý tin nhắn server channel
     */
    private void handleServerMessage(WebSocketSession session, Map<String, Object> messageData) throws Exception {
        Long senderId = sessionToUserId.get(session);
        if (senderId == null) {
            sendError(session, "Bạn cần đăng ký userId trước khi gửi tin nhắn");
            return;
        }

        Long channelId = getLongValue(messageData.get("channelId"));
        String content = (String) messageData.get("content");

        if (channelId == null || content == null || content.trim().isEmpty()) {
            sendError(session, "Thiếu thông tin channelId hoặc content");
            return;
        }

        Channel channel = channelRepository.findById(channelId)
            .orElseThrow(() -> new Exception("Channel not found"));

        User sender = userRepository.findById(senderId)
            .orElseThrow(() -> new Exception("User not found"));

        // Check if user is member of server
        if (!serverMemberRepository.existsByServerAndUser(channel.getServer(), sender)) {
            sendError(session, "Bạn không phải là thành viên của server này");
            return;
        }

        // Only text channels can have messages
        if (channel.getType() != ChannelType.TEXT) {
            sendError(session, "Voice channels không hỗ trợ tin nhắn");
            return;
        }

        // Save message to database
        ServerMessage serverMessage = new ServerMessage();
        serverMessage.setChannel(channel);
        serverMessage.setSender(sender);
        serverMessage.setContent(content.trim());
        serverMessage = serverMessageRepository.save(serverMessage);

        // Create response message
        Map<String, Object> responseMessage = new HashMap<>();
        responseMessage.put("type", "server_message");
        responseMessage.put("id", serverMessage.getId());
        responseMessage.put("channelId", channelId);
        responseMessage.put("senderId", senderId);
        responseMessage.put("senderUsername", sender.getUsername());
        if (sender.getAvatarUrl() != null) {
            responseMessage.put("senderAvatarUrl", sender.getAvatarUrl());
        }
        responseMessage.put("content", serverMessage.getContent());
        responseMessage.put("createdAt", serverMessage.getCreatedAt().toString());

        // Send to all subscribers of this channel
        sendToChannel(channelId, responseMessage, senderId);

        logger.info("💬 Server message từ " + senderId + " trong channel " + channelId);
    }

    /**
     * Subscribe to a channel for real-time messages
     */
    private void handleSubscribeChannel(WebSocketSession session, Map<String, Object> messageData) {
        Long userId = sessionToUserId.get(session);
        if (userId == null) {
            sendError(session, "Bạn cần đăng ký userId trước");
            return;
        }

        Long channelId = getLongValue(messageData.get("channelId"));
        if (channelId == null) {
            sendError(session, "Thiếu channelId");
            return;
        }

        channelSubscribers.computeIfAbsent(channelId, k -> Collections.synchronizedSet(new HashSet<>())).add(userId);
        logger.info("📢 User " + userId + " subscribed to channel " + channelId);
    }

    /**
     * Unsubscribe from a channel
     */
    private void handleUnsubscribeChannel(WebSocketSession session, Map<String, Object> messageData) {
        Long userId = sessionToUserId.get(session);
        if (userId == null) {
            return;
        }

        Long channelId = getLongValue(messageData.get("channelId"));
        if (channelId == null) {
            return;
        }

        Set<Long> subscribers = channelSubscribers.get(channelId);
        if (subscribers != null) {
            subscribers.remove(userId);
            if (subscribers.isEmpty()) {
                channelSubscribers.remove(channelId);
            }
        }
        logger.info("📢 User " + userId + " unsubscribed from channel " + channelId);
    }

    /**
     * Handle voice channel join
     */
    private void handleVoiceJoin(WebSocketSession session, Map<String, Object> messageData) {
        Long userId = sessionToUserId.get(session);
        if (userId == null) {
            sendError(session, "Bạn cần đăng ký userId trước");
            return;
        }

        Long channelId = getLongValue(messageData.get("channelId"));
        if (channelId == null) {
            sendError(session, "Thiếu channelId");
            return;
        }

        try {
            // Sử dụng service để join channel
            Map<String, Object> result = voiceChannelService.joinVoiceChannel(userId, channelId);
            List<Map<String, Object>> usersList = (List<Map<String, Object>>) result.get("users");
            
            // Gửi danh sách users hiện tại cho user vừa join
            if (usersList != null && !usersList.isEmpty()) {
                Map<String, Object> usersListMessage = new HashMap<>();
                usersListMessage.put("type", "voice_users_list");
                usersListMessage.put("channelId", channelId);
                usersListMessage.put("users", usersList);
                sendMessage(session, usersListMessage);
            }

            // Thông báo cho các users khác trong channel
            Map<String, Object> notification = new HashMap<>();
            notification.put("type", "voice_user_joined");
            notification.put("channelId", channelId);
            notification.put("userId", userId);
            
            // Include user info in notification
            userRepository.findById(userId).ifPresent(user -> {
                notification.put("username", user.getUsername());
                notification.put("avatarUrl", user.getAvatarUrl() != null ? user.getAvatarUrl() : "");
            });
            
            sendToChannelUsers(channelId, notification, userId);

            logger.info("🎤 User " + userId + " joined voice channel " + channelId);
        } catch (Exception e) {
            sendError(session, e.getMessage());
            logger.warning("Error joining voice channel: " + e.getMessage());
        }
    }

    /**
     * Handle voice channel leave
     */
    private void handleVoiceLeave(WebSocketSession session, Map<String, Object> messageData) {
        Long userId = sessionToUserId.get(session);
        if (userId == null) {
            logger.warning("User tried to leave voice channel but userId is null");
            return;
        }

        Long channelId = getLongValue(messageData.get("channelId"));
        if (channelId == null) {
            sendError(session, "Thiếu channelId");
            logger.warning("User " + userId + " tried to leave voice channel but channelId is null");
            return;
        }

        // Sử dụng service để leave channel
        voiceChannelService.leaveVoiceChannel(userId, channelId);

        // Notify other users
        Map<String, Object> notification = new HashMap<>();
        notification.put("type", "voice_user_left");
        notification.put("channelId", channelId);
        notification.put("userId", userId);
        
        // Include user info in notification
        userRepository.findById(userId).ifPresent(user -> {
            notification.put("username", user.getUsername());
            notification.put("avatarUrl", user.getAvatarUrl() != null ? user.getAvatarUrl() : "");
        });
        
        sendToChannelUsers(channelId, notification, userId);

        logger.info("🎤 User " + userId + " left voice channel " + channelId);
    }

    /**
     * Handle WebRTC signaling for voice channels
     */
    private void handleVoiceSignal(WebSocketSession session, Map<String, Object> messageData) {
        Long senderId = sessionToUserId.get(session);
        if (senderId == null) {
            return;
        }

        Long channelId = getLongValue(messageData.get("channelId"));
        Long targetUserId = getLongValue(messageData.get("targetUserId"));
        Object signal = messageData.get("signal");

        if (channelId == null || targetUserId == null || signal == null) {
            return;
        }

        // Forward WebRTC signal to target user
        Map<String, Object> signalMessage = new HashMap<>();
        signalMessage.put("type", "voice_signal");
        signalMessage.put("channelId", channelId);
        signalMessage.put("fromUserId", senderId);
        signalMessage.put("signal", signal);
        sendToUser(targetUserId, signalMessage);
    }

    /**
     * Handle voice mute toggle
     */
    private void handleVoiceMute(WebSocketSession session, Map<String, Object> messageData) {
        Long userId = sessionToUserId.get(session);
        if (userId == null) {
            sendError(session, "Bạn cần đăng ký userId trước");
            return;
        }

        Long channelId = getLongValue(messageData.get("channelId"));
        Object mutedObj = messageData.get("muted");
        Boolean muted = null;
        
        // Handle different types of muted value
        if (mutedObj instanceof Boolean) {
            muted = (Boolean) mutedObj;
        } else if (mutedObj instanceof String) {
            muted = Boolean.parseBoolean((String) mutedObj);
        } else if (mutedObj != null) {
            muted = Boolean.valueOf(mutedObj.toString());
        }
        
        if (channelId == null || muted == null) {
            sendError(session, "Thiếu channelId hoặc muted");
            return;
        }

        try {
            // Sử dụng service để cập nhật mute state
            voiceChannelService.updateMuteState(userId, channelId, muted);

            // Notify other users in the voice channel
            Map<String, Object> notification = new HashMap<>();
            notification.put("type", "voice_user_muted");
            notification.put("channelId", channelId);
            notification.put("userId", userId);
            notification.put("muted", muted);
            
            userRepository.findById(userId).ifPresent(user -> {
                notification.put("username", user.getUsername());
                notification.put("avatarUrl", user.getAvatarUrl() != null ? user.getAvatarUrl() : "");
            });
            
            sendToChannelUsers(channelId, notification, userId);

            logger.info("🎤 User " + userId + " " + (muted ? "muted" : "unmuted") + " in voice channel " + channelId);
        } catch (Exception e) {
            sendError(session, e.getMessage());
            logger.warning("Error updating mute state: " + e.getMessage());
        }
    }

    /**
     * Handle voice deafen toggle
     */
    private void handleVoiceDeafen(WebSocketSession session, Map<String, Object> messageData) {
        Long userId = sessionToUserId.get(session);
        if (userId == null) {
            sendError(session, "Bạn cần đăng ký userId trước");
            return;
        }

        Long channelId = getLongValue(messageData.get("channelId"));
        Object deafenedObj = messageData.get("deafened");
        Boolean deafened = null;
        
        // Handle different types of deafened value
        if (deafenedObj instanceof Boolean) {
            deafened = (Boolean) deafenedObj;
        } else if (deafenedObj instanceof String) {
            deafened = Boolean.parseBoolean((String) deafenedObj);
        } else if (deafenedObj != null) {
            deafened = Boolean.valueOf(deafenedObj.toString());
        }
        
        if (channelId == null || deafened == null) {
            sendError(session, "Thiếu channelId hoặc deafened");
            return;
        }

        try {
            // Sử dụng service để cập nhật deafen state
            voiceChannelService.updateDeafenState(userId, channelId, deafened);

            // Notify other users in the voice channel
            Map<String, Object> notification = new HashMap<>();
            notification.put("type", "voice_user_deafened");
            notification.put("channelId", channelId);
            notification.put("userId", userId);
            notification.put("deafened", deafened);
            
            userRepository.findById(userId).ifPresent(user -> {
                notification.put("username", user.getUsername());
                notification.put("avatarUrl", user.getAvatarUrl() != null ? user.getAvatarUrl() : "");
            });
            
            sendToChannelUsers(channelId, notification, userId);

            logger.info("🔊 User " + userId + " " + (deafened ? "deafened" : "undeafened") + " in voice channel " + channelId);
        } catch (Exception e) {
            sendError(session, e.getMessage());
            logger.warning("Error updating deafen state: " + e.getMessage());
        }
    }

    /**
     * Handle voice video toggle
     */
    private void handleVoiceVideo(WebSocketSession session, Map<String, Object> messageData) {
        Long userId = sessionToUserId.get(session);
        if (userId == null) {
            sendError(session, "Bạn cần đăng ký userId trước");
            return;
        }

        Long channelId = getLongValue(messageData.get("channelId"));
        Object videoEnabledObj = messageData.get("videoEnabled");
        Boolean videoEnabled = null;
        
        // Handle different types of videoEnabled value
        if (videoEnabledObj instanceof Boolean) {
            videoEnabled = (Boolean) videoEnabledObj;
        } else if (videoEnabledObj instanceof String) {
            videoEnabled = Boolean.parseBoolean((String) videoEnabledObj);
        } else if (videoEnabledObj != null) {
            videoEnabled = Boolean.valueOf(videoEnabledObj.toString());
        }
        
        if (channelId == null || videoEnabled == null) {
            sendError(session, "Thiếu channelId hoặc videoEnabled");
            return;
        }

        try {
            // Sử dụng service để cập nhật video state
            voiceChannelService.updateVideoState(userId, channelId, videoEnabled);

            // Notify other users in the voice channel
            Map<String, Object> notification = new HashMap<>();
            notification.put("type", "voice_user_video");
            notification.put("channelId", channelId);
            notification.put("userId", userId);
            notification.put("videoEnabled", videoEnabled);
            
            userRepository.findById(userId).ifPresent(user -> {
                notification.put("username", user.getUsername());
                notification.put("avatarUrl", user.getAvatarUrl() != null ? user.getAvatarUrl() : "");
            });
            
            sendToChannelUsers(channelId, notification, userId);

            logger.info("📹 User " + userId + " " + (videoEnabled ? "enabled" : "disabled") + " video in voice channel " + channelId);
        } catch (Exception e) {
            sendError(session, e.getMessage());
            logger.warning("Error updating video state: " + e.getMessage());
        }
    }

    /**
     * Gửi tin nhắn đến tất cả subscribers của channel
     */
    private void sendToChannel(Long channelId, Map<String, Object> message, Long excludeUserId) {
        Set<Long> subscribers = channelSubscribers.get(channelId);
        if (subscribers != null) {
            subscribers.forEach(userId -> {
                if (!userId.equals(excludeUserId)) {
                    sendToUser(userId, message);
                }
            });
        }
    }

    /**
     * Gửi tin nhắn đến tất cả users trong voice channel
     */
    private void sendToChannelUsers(Long channelId, Map<String, Object> message, Long excludeUserId) {
        Set<Long> users = voiceChannelService.getChannelUserIds(channelId);
        if (users != null && !users.isEmpty()) {
            users.forEach(userId -> {
                if (!userId.equals(excludeUserId)) {
                    sendToUser(userId, message);
                }
            });
        }
    }
    
    /**
     * Gửi tin nhắn đến một user cụ thể (tất cả sessions của user đó)
     */
    private void sendToUser(Long userId, Map<String, Object> message) {
        Set<WebSocketSession> sessions = userSessions.get(userId);
        if (sessions != null && !sessions.isEmpty()) {
            sessions.removeIf(s -> {
                if (!s.isOpen()) {
                    return true; // Remove closed sessions
                }
                try {
                    sendMessage(s, message);
                    return false;
                } catch (Exception e) {
                    logger.warning("✗ Lỗi gửi tin nhắn đến session: " + e.getMessage());
                    return true; // Remove failed sessions
                }
            });
            
            // Cleanup nếu không còn session nào
            if (sessions.isEmpty()) {
                userSessions.remove(userId);
            }
        }
    }
    
    /**
     * Gửi tin nhắn đến một session
     */
    private void sendMessage(WebSocketSession session, Map<String, Object> data) {
        try {
            String json = objectMapper.writeValueAsString(data);
            session.sendMessage(new TextMessage(json));
        } catch (IOException e) {
            logger.warning("✗ Lỗi gửi tin nhắn: " + e.getMessage());
        }
    }
    
    /**
     * Gửi lỗi đến session
     */
    private void sendError(WebSocketSession session, String errorMessage) {
        sendMessage(session, Map.of(
            "type", "error",
            "message", errorMessage
        ));
    }
    
    @Override
    public void afterConnectionClosed(WebSocketSession session, org.springframework.web.socket.CloseStatus status) throws Exception {
        Long userId = sessionToUserId.remove(session);
        
        if (userId != null) {
            Set<WebSocketSession> sessions = userSessions.get(userId);
            if (sessions != null) {
                sessions.remove(session);
                if (sessions.isEmpty()) {
                    userSessions.remove(userId);
                    onlineUserIds.remove(userId);
                    
                    // Remove from all channel subscriptions
                    channelSubscribers.values().forEach(subscribers -> subscribers.remove(userId));
                    channelSubscribers.entrySet().removeIf(entry -> entry.getValue().isEmpty());
                    
                    // Remove from all voice channels using service
                    voiceChannelService.cleanupUserState(userId);
                    
                    // Update lastSeen when user goes offline
                    try {
                        userRepository.findById(userId).ifPresent(user -> {
                            user.setLastSeen(java.time.LocalDateTime.now());
                            userRepository.save(user);
                        });
                    } catch (Exception e) {
                        logger.warning("✗ Lỗi cập nhật lastSeen: " + e.getMessage());
                    }
                    logger.info("✗ User " + userId + " offline (không còn session nào)");
                } else {
                    logger.info("✗ User " + userId + " đóng một session (còn " + sessions.size() + " session)");
                }
            }
        }
        
        logger.info("✗ WebSocket ngắt kết nối: " + session.getId() + " (còn " + userSessions.size() + " users online)");
    }
    
    @Override
    public void handleTransportError(WebSocketSession session, Throwable exception) throws Exception {
        logger.severe("✗ Lỗi WebSocket transport: " + exception.getMessage());
        exception.printStackTrace();
    }
    
    /**
     * Helper: Convert Object to Long
     */
    private Long getLongValue(Object obj) {
        if (obj == null) return null;
        if (obj instanceof Long) return (Long) obj;
        if (obj instanceof Integer) return ((Integer) obj).longValue();
        if (obj instanceof String) {
            try {
                return Long.parseLong((String) obj);
            } catch (NumberFormatException e) {
                return null;
            }
        }
        return null;
    }
}
