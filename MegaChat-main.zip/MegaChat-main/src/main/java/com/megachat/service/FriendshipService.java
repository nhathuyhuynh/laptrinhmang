package com.megachat.service;

import com.megachat.model.Friendship;
import com.megachat.model.FriendshipStatus;
import com.megachat.model.User;
import com.megachat.repository.FriendshipRepository;
import com.megachat.repository.UserRepository;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class FriendshipService {

    private final FriendshipRepository friendshipRepository;
    private final UserRepository userRepository;
    private final UserService userService;

    public FriendshipService(FriendshipRepository friendshipRepository, 
                             UserRepository userRepository,
                             UserService userService) {
        this.friendshipRepository = friendshipRepository;
        this.userRepository = userRepository;
        this.userService = userService;
    }

    /**
     * Lấy danh sách bạn bè đã chấp nhận với trạng thái online/offline
     */
    public List<UserWithOnlineStatus> getAcceptedFriendsWithOnlineStatus(Long userId) throws Exception {
        User user = getUserOrThrow(userId);
        Set<Long> onlineUserIds = com.megachat.websocket.ChatEndpoint.getOnlineUserIds();
        
        return friendshipRepository.findAcceptedFriendships(user)
            .stream()
            .map(friendship -> {
                User friend = friendship.getRequester().equals(user)
                    ? friendship.getReceiver()
                    : friendship.getRequester();
                boolean isOnline = onlineUserIds.contains(friend.getId());
                return new UserWithOnlineStatus(friend, isOnline);
            })
            .collect(Collectors.toList());
    }

    /**
     * Inner class để chứa user và trạng thái online
     */
    public static class UserWithOnlineStatus {
        private final User user;
        private final boolean online;
        
        public UserWithOnlineStatus(User user, boolean online) {
            this.user = user;
            this.online = online;
        }
        
        public User getUser() {
            return user;
        }
        
        public boolean isOnline() {
            return online;
        }
    }

    /**
     * Lấy danh sách lời mời đến (incoming requests)
     */
    public List<Friendship> getIncomingRequests(Long userId) throws Exception {
        User user = getUserOrThrow(userId);
        List<Friendship> incoming = friendshipRepository.findByReceiverAndStatus(user, FriendshipStatus.PENDING);
        System.out.println("=== GET INCOMING REQUESTS ===");
        System.out.println("User ID: " + userId);
        System.out.println("Found " + incoming.size() + " incoming requests");
        incoming.forEach(f -> System.out.println("  - Request ID: " + f.getId() + ", From: " + f.getRequester().getUsername()));
        return incoming;
    }

    /**
     * Lấy danh sách lời mời đã gửi (outgoing requests)
     */
    public List<Friendship> getOutgoingRequests(Long userId) throws Exception {
        User user = getUserOrThrow(userId);
        return friendshipRepository.findByRequesterAndStatus(user, FriendshipStatus.PENDING);
    }

    /**
     * Gửi lời mời kết bạn
     */
    @Transactional
    public Friendship sendRequest(Long requesterId, String targetUsername, String message) throws Exception {
        System.out.println("=== SENDING FRIEND REQUEST ===");
        System.out.println("Requester ID: " + requesterId);
        System.out.println("Target Username: " + targetUsername);
        
        // Validate input
        if (targetUsername == null || targetUsername.trim().isEmpty()) {
            throw new Exception("Vui lòng nhập username người nhận");
        }

        // Get users
        User requester = getUserOrThrow(requesterId);
        System.out.println("Requester found: " + requester.getUsername() + " (ID: " + requester.getId() + ")");
        
        User receiver = userRepository.findByUsername(targetUsername.trim())
            .orElseThrow(() -> new Exception("Không tìm thấy người dùng có username: " + targetUsername));
        System.out.println("Receiver found: " + receiver.getUsername() + " (ID: " + receiver.getId() + ")");

        // Check self-request
        if (requester.getId().equals(receiver.getId())) {
            throw new Exception("Không thể tự gửi lời mời cho chính mình");
        }

        // Check existing friendship
        Optional<Friendship> existing = friendshipRepository.findFriendshipBetweenUsers(requester, receiver);
        System.out.println("Existing friendship check: " + (existing.isPresent() ? "FOUND" : "NOT FOUND"));
        
        if (existing.isPresent()) {
            Friendship f = existing.get();
            System.out.println("Existing friendship status: " + f.getStatus());
            if (f.getStatus() == FriendshipStatus.ACCEPTED) {
                throw new Exception("Bạn đã là bạn bè với người này");
            } else if (f.getStatus() == FriendshipStatus.PENDING) {
                if (f.getRequester().getId().equals(requesterId)) {
                    throw new Exception("Bạn đã gửi lời mời kết bạn cho người này");
                } else {
                    throw new Exception("Người này đã gửi lời mời kết bạn cho bạn. Vui lòng kiểm tra tab Pending");
                }
            } else if (f.getStatus() == FriendshipStatus.DECLINED) {
                // Xóa friendship cũ và tạo mới
                System.out.println("Deleting declined friendship with ID: " + f.getId());
                Long oldId = f.getId();
                friendshipRepository.delete(f);
                friendshipRepository.flush();
                
                // Verify deletion
                Optional<Friendship> verifyDelete = friendshipRepository.findById(oldId);
                if (verifyDelete.isPresent()) {
                    System.out.println("✗ WARNING: Friendship still exists after delete, will try to update instead");
                    // Nếu vẫn tồn tại, reload và cập nhật thay vì tạo mới
                    Friendship existingF = verifyDelete.get();
                    existingF.setStatus(FriendshipStatus.PENDING);
                    existingF.setMessage(message != null && !message.trim().isEmpty() ? message.trim() : null);
                    existingF.setCreatedAt(LocalDateTime.now());
                    existingF.setRespondedAt(null);
                    Friendship updated = friendshipRepository.saveAndFlush(existingF);
                    System.out.println("✓ Updated declined friendship to PENDING with ID: " + updated.getId());
                    return updated;
                }
                System.out.println("✓ Declined friendship deleted successfully");
            }
        }

        // Create new friendship
        Friendship friendship = new Friendship();
        friendship.setRequester(requester);
        friendship.setReceiver(receiver);
        friendship.setStatus(FriendshipStatus.PENDING);
        friendship.setMessage(message != null && !message.trim().isEmpty() ? message.trim() : null);
        friendship.setBlocked(false);

        System.out.println("Saving friendship to database...");
        try {
            // Save to database
            Friendship saved = friendshipRepository.saveAndFlush(friendship);
            System.out.println("Friendship saved with ID: " + saved.getId());
            System.out.println("Friendship createdAt: " + saved.getCreatedAt());
            System.out.println("Friendship status: " + saved.getStatus());
            
            // Verify it was saved
            Optional<Friendship> verify = friendshipRepository.findById(saved.getId());
            if (verify.isPresent()) {
                System.out.println("✓ Friendship verified in database");
                return saved;
            } else {
                System.out.println("✗ ERROR: Friendship not found after save!");
                throw new Exception("Lỗi: Không thể lưu lời mời kết bạn vào database");
            }
        } catch (DataIntegrityViolationException e) {
            System.out.println("✗ ERROR: Data integrity violation: " + e.getMessage());
            e.printStackTrace();
            
            // Kiểm tra lại xem có phải do unique constraint không
            Optional<Friendship> checkAgain = friendshipRepository.findFriendshipBetweenUsers(requester, receiver);
            if (checkAgain.isPresent()) {
                Friendship existingF = checkAgain.get();
                System.out.println("Found existing friendship after error: " + existingF.getStatus());
                if (existingF.getStatus() == FriendshipStatus.PENDING) {
                    if (existingF.getRequester().getId().equals(requesterId)) {
                        throw new Exception("Bạn đã gửi lời mời kết bạn cho người này");
                    } else {
                        throw new Exception("Người này đã gửi lời mời kết bạn cho bạn. Vui lòng kiểm tra tab Pending");
                    }
                } else if (existingF.getStatus() == FriendshipStatus.ACCEPTED) {
                    throw new Exception("Bạn đã là bạn bè với người này");
                } else if (existingF.getStatus() == FriendshipStatus.DECLINED) {
                    // Cập nhật DECLINED thành PENDING
                    existingF.setStatus(FriendshipStatus.PENDING);
                    existingF.setMessage(message != null && !message.trim().isEmpty() ? message.trim() : null);
                    existingF.setCreatedAt(LocalDateTime.now());
                    existingF.setRespondedAt(null);
                    Friendship updated = friendshipRepository.saveAndFlush(existingF);
                    System.out.println("✓ Updated declined friendship to PENDING");
                    return updated;
                }
            }
            throw new Exception("Lỗi: Không thể tạo lời mời kết bạn. Vui lòng thử lại.");
        } catch (Exception e) {
            System.out.println("✗ ERROR: Unexpected error: " + e.getMessage());
            e.printStackTrace();
            throw new Exception("Lỗi: " + e.getMessage());
        }
    }

    /**
     * Chấp nhận lời mời kết bạn
     */
    @Transactional
    public Friendship acceptRequest(Long requestId, Long receiverId) throws Exception {
        User receiver = getUserOrThrow(receiverId);
        Friendship friendship = friendshipRepository.findByIdAndReceiver(requestId, receiver)
            .orElseThrow(() -> new Exception("Không tìm thấy lời mời kết bạn"));

        if (friendship.getStatus() != FriendshipStatus.PENDING) {
            throw new Exception("Lời mời đã được xử lý trước đó");
        }

        friendship.setStatus(FriendshipStatus.ACCEPTED);
        friendship.setRespondedAt(LocalDateTime.now());
        return friendshipRepository.saveAndFlush(friendship);
    }

    /**
     * Từ chối lời mời kết bạn
     */
    @Transactional
    public Friendship declineRequest(Long requestId, Long receiverId) throws Exception {
        User receiver = getUserOrThrow(receiverId);
        Friendship friendship = friendshipRepository.findByIdAndReceiver(requestId, receiver)
            .orElseThrow(() -> new Exception("Không tìm thấy lời mời kết bạn"));

        if (friendship.getStatus() != FriendshipStatus.PENDING) {
            throw new Exception("Lời mời đã được xử lý trước đó");
        }

        friendship.setStatus(FriendshipStatus.DECLINED);
        friendship.setRespondedAt(LocalDateTime.now());
        return friendshipRepository.saveAndFlush(friendship);
    }

    /**
     * Xóa bạn bè (unfriend)
     */
    @Transactional
    public void unfriend(Long userId, Long friendId) throws Exception {
        User user = getUserOrThrow(userId);
        User friend = userRepository.findById(friendId)
            .orElseThrow(() -> new Exception("Không tìm thấy người bạn"));

        if (user.getId().equals(friendId)) {
            throw new Exception("Không thể tự xóa chính mình");
        }

        Friendship friendship = friendshipRepository.findAcceptedFriendship(user, friend)
            .orElseThrow(() -> new Exception("Hai người chưa là bạn bè"));

        friendshipRepository.delete(friendship);
    }

    /**
     * Cập nhật biệt danh cho bạn bè
     */
    @Transactional
    public Friendship updateNickname(Long userId, Long friendId, String nickname) throws Exception {
        User user = getUserOrThrow(userId);
        User friend = userRepository.findById(friendId)
            .orElseThrow(() -> new Exception("Không tìm thấy người bạn"));

        Friendship friendship = friendshipRepository.findAcceptedFriendship(user, friend)
            .orElseThrow(() -> new Exception("Hai người chưa là bạn bè"));

        friendship.setNickname(nickname != null && !nickname.trim().isEmpty() ? nickname.trim() : null);
        return friendshipRepository.saveAndFlush(friendship);
    }

    /**
     * Chặn/bỏ chặn tin nhắn từ bạn bè
     */
    @Transactional
    public Friendship toggleBlock(Long userId, Long friendId, boolean blocked) throws Exception {
        User user = getUserOrThrow(userId);
        User friend = userRepository.findById(friendId)
            .orElseThrow(() -> new Exception("Không tìm thấy người bạn"));

        Friendship friendship = friendshipRepository.findAcceptedFriendship(user, friend)
            .orElseThrow(() -> new Exception("Hai người chưa là bạn bè"));

        friendship.setBlocked(blocked);
        return friendshipRepository.saveAndFlush(friendship);
    }

    /**
     * Lấy friendship giữa hai user (chỉ ACCEPTED)
     */
    public Friendship getFriendship(Long userId, Long friendId) throws Exception {
        User user = getUserOrThrow(userId);
        User friend = userRepository.findById(friendId)
            .orElseThrow(() -> new Exception("Không tìm thấy người bạn"));

        return friendshipRepository.findAcceptedFriendship(user, friend)
            .orElseThrow(() -> new Exception("Hai người chưa là bạn bè"));
    }

    /**
     * Lấy trạng thái kết bạn giữa hai user (bất kỳ trạng thái nào)
     */
    public Optional<Friendship> getFriendshipStatus(Long userId, Long friendId) {
        try {
            User user = userRepository.findById(userId).orElse(null);
            User friend = userRepository.findById(friendId).orElse(null);
            
            if (user == null || friend == null || userId.equals(friendId)) {
                return Optional.empty();
            }
            
            return friendshipRepository.findFriendshipBetweenUsers(user, friend);
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    /**
     * Tìm kiếm user theo username hoặc email
     */
    public List<User> searchUsers(String keyword, Long excludeUserId) {
        return userService.searchUsers(keyword, excludeUserId);
    }

    /**
     * Helper method: Get user or throw exception
     */
    private User getUserOrThrow(Long userId) throws Exception {
        if (userId == null) {
            throw new Exception("Bạn chưa đăng nhập");
        }
        return userRepository.findById(userId)
            .orElseThrow(() -> new Exception("Không tìm thấy người dùng"));
    }
}

