package com.megachat.service;

import com.megachat.model.*;
import com.megachat.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ServerService {

    private final ServerRepository serverRepository;
    private final ChannelRepository channelRepository;
    private final ServerMemberRepository serverMemberRepository;
    private final ServerInvitationRepository serverInvitationRepository;
    private final ServerMessageRepository serverMessageRepository;
    private final UserRepository userRepository;
    private final FriendshipRepository friendshipRepository;

    public ServerService(ServerRepository serverRepository,
                        ChannelRepository channelRepository,
                        ServerMemberRepository serverMemberRepository,
                        ServerInvitationRepository serverInvitationRepository,
                        ServerMessageRepository serverMessageRepository,
                        UserRepository userRepository,
                        FriendshipRepository friendshipRepository) {
        this.serverRepository = serverRepository;
        this.channelRepository = channelRepository;
        this.serverMemberRepository = serverMemberRepository;
        this.userRepository = userRepository;
        this.serverInvitationRepository = serverInvitationRepository;
        this.serverMessageRepository = serverMessageRepository;
        this.friendshipRepository = friendshipRepository;
    }

    @Transactional
    public Server createServer(Long ownerId, String name, String description) throws Exception {
        User owner = userRepository.findById(ownerId)
            .orElseThrow(() -> new Exception("User not found"));

        Server server = new Server();
        server.setName(name);
        server.setDescription(description);
        server.setOwner(owner);
        server = serverRepository.save(server);

        // Add owner as member
        ServerMember member = new ServerMember(server, owner);
        serverMemberRepository.save(member);

        // Create default channels
        Channel generalText = new Channel("general", ChannelType.TEXT, server);
        generalText.setPosition(0);
        channelRepository.save(generalText);

        Channel generalVoice = new Channel("General", ChannelType.VOICE, server);
        generalVoice.setPosition(1);
        channelRepository.save(generalVoice);

        return server;
    }

    public List<Server> getUserServers(Long userId) {
        return serverRepository.findByMemberUserId(userId);
    }

    public Server getServerById(Long serverId, Long userId) throws Exception {
        Server server = serverRepository.findById(serverId)
            .orElseThrow(() -> new Exception("Server not found"));

        // Check if user is member
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new Exception("User not found"));

        if (!serverMemberRepository.existsByServerAndUser(server, user)) {
            throw new Exception("You are not a member of this server");
        }

        return server;
    }

    @Transactional
    public Server updateServer(Long serverId, Long userId, String name, String description, String iconUrl) throws Exception {
        Server server = getServerById(serverId, userId);

        // Check if user is owner
        if (!server.getOwner().getId().equals(userId)) {
            throw new Exception("Only server owner can update server");
        }

        if (name != null && !name.trim().isEmpty()) {
            server.setName(name.trim());
        }
        if (description != null) {
            server.setDescription(description);
        }
        if (iconUrl != null) {
            server.setIconUrl(iconUrl);
        }

        return serverRepository.save(server);
    }

    @Transactional
    public void deleteServer(Long serverId, Long userId) throws Exception {
        Server server = getServerById(serverId, userId);

        // Check if user is owner
        if (!server.getOwner().getId().equals(userId)) {
            throw new Exception("Only server owner can delete server");
        }

        // Delete all related data in correct order to avoid constraint violations
        // 1. Delete all server messages (through channels)
        // First, set reply_to_id to null for all messages to avoid foreign key constraint
        List<Channel> channels = channelRepository.findByServerIdOrderByPositionAsc(serverId);
        for (Channel channel : channels) {
            List<ServerMessage> messages = serverMessageRepository.findByChannelIdOrderByIdDesc(channel.getId());
            for (ServerMessage message : messages) {
                message.setReplyTo(null); // Clear reply reference
                serverMessageRepository.save(message);
            }
        }
        serverMessageRepository.flush(); // Ensure updates are committed
        
        // Now delete all messages
        for (Channel channel : channels) {
            List<ServerMessage> messages = serverMessageRepository.findByChannelIdOrderByIdDesc(channel.getId());
            if (!messages.isEmpty()) {
                serverMessageRepository.deleteAll(messages);
            }
        }
        serverMessageRepository.flush(); // Ensure deletion is committed

        // 2. Delete all channels
        if (!channels.isEmpty()) {
            channelRepository.deleteAll(channels);
            channelRepository.flush(); // Ensure deletion is committed
        }

        // 3. Delete all server members
        List<ServerMember> members = serverMemberRepository.findByServerId(serverId);
        if (!members.isEmpty()) {
            serverMemberRepository.deleteAll(members);
            serverMemberRepository.flush(); // Ensure deletion is committed
        }

        // 4. Delete all server invitations
        List<ServerInvitation> invitations = serverInvitationRepository.findByServerId(serverId);
        if (!invitations.isEmpty()) {
            serverInvitationRepository.deleteAll(invitations);
            serverInvitationRepository.flush(); // Ensure deletion is committed
        }

        // 5. Finally delete the server
        serverRepository.delete(server);
        serverRepository.flush(); // Ensure deletion is committed
    }

    @Transactional
    public ServerInvitation createInvitation(Long serverId, Long userId, Integer maxUses, Integer expiresInDays) throws Exception {
        Server server = getServerById(serverId, userId);

        // Check if user is owner or member
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new Exception("User not found"));

        if (!server.getOwner().getId().equals(userId) && 
            !serverMemberRepository.existsByServerAndUser(server, user)) {
            throw new Exception("You don't have permission to create invitations");
        }

        String inviteCode = generateInviteCode();
        ServerInvitation invitation = new ServerInvitation();
        invitation.setServer(server);
        invitation.setCreatedBy(user);
        invitation.setInviteCode(inviteCode);
        invitation.setMaxUses(maxUses);
        
        if (expiresInDays != null && expiresInDays > 0) {
            invitation.setExpiresAt(LocalDateTime.now().plusDays(expiresInDays));
        }

        return serverInvitationRepository.save(invitation);
    }

    @Transactional
    public Server joinServerByInvite(Long userId, String inviteCode) throws Exception {
        ServerInvitation invitation = serverInvitationRepository.findByInviteCode(inviteCode)
            .orElseThrow(() -> new Exception("Invalid invite code"));

        if (!invitation.isValid()) {
            throw new Exception("Invitation has expired or reached max uses");
        }

        User user = userRepository.findById(userId)
            .orElseThrow(() -> new Exception("User not found"));

        Server server = invitation.getServer();

        // Check if already a member
        if (serverMemberRepository.existsByServerAndUser(server, user)) {
            throw new Exception("You are already a member of this server");
        }

        // Add user as member
        ServerMember member = new ServerMember(server, user);
        serverMemberRepository.save(member);

        // Update invitation uses
        invitation.setUsesCount(invitation.getUsesCount() + 1);
        serverInvitationRepository.save(invitation);

        return server;
    }

    @Transactional
    public void inviteFriendToServer(Long serverId, Long userId, Long friendId) throws Exception {
        Server server = getServerById(serverId, userId);
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new Exception("User not found"));
        User friend = userRepository.findById(friendId)
            .orElseThrow(() -> new Exception("Friend not found"));

        // Check if user is member of server
        if (!server.getOwner().getId().equals(userId) && 
            !serverMemberRepository.existsByServerAndUser(server, user)) {
            throw new Exception("You are not a member of this server");
        }

        // Check if friend is already a member
        if (serverMemberRepository.existsByServerAndUser(server, friend)) {
            throw new Exception("This user is already a member of this server");
        }

        // Check if they are friends
        if (!friendshipRepository.existsAcceptedFriendship(user, friend)) {
            throw new Exception("You can only invite your friends to the server");
        }

        // Add friend as member
        ServerMember member = new ServerMember(server, friend);
        serverMemberRepository.save(member);
    }

    @Transactional
    public void leaveServer(Long serverId, Long userId) throws Exception {
        Server server = getServerById(serverId, userId);
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new Exception("User not found"));

        // Owner cannot leave
        if (server.getOwner().getId().equals(userId)) {
            throw new Exception("Server owner cannot leave the server");
        }

        ServerMember member = serverMemberRepository.findByServerAndUser(server, user)
            .orElseThrow(() -> new Exception("You are not a member of this server"));

        serverMemberRepository.delete(member);
    }

    @Transactional
    public void removeMember(Long serverId, Long userId, Long memberId) throws Exception {
        Server server = getServerById(serverId, userId);

        // Check if user is owner
        if (!server.getOwner().getId().equals(userId)) {
            throw new Exception("Only server owner can remove members");
        }

        User memberUser = userRepository.findById(memberId)
            .orElseThrow(() -> new Exception("Member not found"));

        // Cannot remove owner
        if (server.getOwner().getId().equals(memberId)) {
            throw new Exception("Cannot remove server owner");
        }

        ServerMember member = serverMemberRepository.findByServerAndUser(server, memberUser)
            .orElseThrow(() -> new Exception("User is not a member of this server"));

        serverMemberRepository.delete(member);
    }

    public List<User> getServerMembers(Long serverId, Long userId) throws Exception {
        Server server = getServerById(serverId, userId);
        return serverMemberRepository.findByServerId(serverId)
            .stream()
            .map(ServerMember::getUser)
            .collect(Collectors.toList());
    }

    private String generateInviteCode() {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        Random random = new Random();
        StringBuilder code = new StringBuilder();
        for (int i = 0; i < 8; i++) {
            code.append(chars.charAt(random.nextInt(chars.length())));
        }
        return code.toString();
    }
}

