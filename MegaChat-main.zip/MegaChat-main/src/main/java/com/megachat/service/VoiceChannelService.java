package com.megachat.service;

import com.megachat.model.Channel;
import com.megachat.model.ChannelType;
import com.megachat.model.User;
import com.megachat.repository.ChannelRepository;
import com.megachat.repository.ServerMemberRepository;
import com.megachat.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Service quản lý voice channel
 * Xử lý logic business cho voice channels
 */
@Service
public class VoiceChannelService {
    
    // Map channelId -> Set<userId> (users in voice channel)
    private final Map<Long, Set<Long>> voiceChannelUsers = new ConcurrentHashMap<>();
    
    // Map userId -> Map<String, Object> (user voice state: muted, deafened, videoEnabled, channelId)
    private final Map<Long, Map<String, Object>> userVoiceStates = new ConcurrentHashMap<>();
    
    private final ChannelRepository channelRepository;
    private final UserRepository userRepository;
    private final ServerMemberRepository serverMemberRepository;
    
    public VoiceChannelService(ChannelRepository channelRepository,
                              UserRepository userRepository,
                              ServerMemberRepository serverMemberRepository) {
        this.channelRepository = channelRepository;
        this.userRepository = userRepository;
        this.serverMemberRepository = serverMemberRepository;
    }
    
    /**
     * User tham gia voice channel
     * @param userId User ID
     * @param channelId Channel ID
     * @return Map chứa thông tin users hiện tại trong channel và user info
     * @throws Exception Nếu channel không tồn tại hoặc không phải voice channel
     */
    public Map<String, Object> joinVoiceChannel(Long userId, Long channelId) throws Exception {
        // Validate channel
        Channel channel = channelRepository.findById(channelId)
            .orElseThrow(() -> new Exception("Channel không tồn tại"));
        
        if (channel.getType() != ChannelType.VOICE) {
            throw new Exception("Channel này không phải voice channel");
        }
        
        // Kiểm tra user có phải member của server không
        if (!serverMemberRepository.existsByServerAndUser(channel.getServer(), 
                userRepository.findById(userId).orElseThrow(() -> new Exception("User không tồn tại")))) {
            throw new Exception("Bạn không phải là thành viên của server này");
        }
        
        // Thêm user vào channel
        voiceChannelUsers.computeIfAbsent(channelId, k -> ConcurrentHashMap.newKeySet()).add(userId);
        
        // Khởi tạo voice state cho user
        Map<String, Object> userState = new HashMap<>();
        userState.put("channelId", channelId);
        userState.put("muted", false);
        userState.put("deafened", false);
        userState.put("videoEnabled", false);
        userVoiceStates.put(userId, userState);
        
        // Lấy danh sách users hiện tại trong channel
        Set<Long> usersInChannel = voiceChannelUsers.get(channelId);
        List<Map<String, Object>> usersList = new ArrayList<>();
        
        for (Long uid : usersInChannel) {
            if (!uid.equals(userId)) {
                userRepository.findById(uid).ifPresent(user -> {
                    Map<String, Object> userInfo = buildUserInfo(user, uid);
                    usersList.add(userInfo);
                });
            }
        }
        
        Map<String, Object> result = new HashMap<>();
        result.put("users", usersList);
        result.put("channelId", channelId);
        
        return result;
    }
    
    /**
     * User rời khỏi voice channel
     * @param userId User ID
     * @param channelId Channel ID
     * @return true nếu thành công
     */
    public boolean leaveVoiceChannel(Long userId, Long channelId) {
        Set<Long> users = voiceChannelUsers.get(channelId);
        if (users != null && users.contains(userId)) {
            users.remove(userId);
            if (users.isEmpty()) {
                voiceChannelUsers.remove(channelId);
            }
        }
        
        // Xóa voice state
        userVoiceStates.remove(userId);
        
        return true;
    }
    
    /**
     * Cập nhật trạng thái mute của user
     * @param userId User ID
     * @param channelId Channel ID
     * @param muted Trạng thái mute
     * @return Voice state sau khi cập nhật
     * @throws Exception Nếu user không ở trong channel
     */
    public Map<String, Object> updateMuteState(Long userId, Long channelId, boolean muted) throws Exception {
        validateUserInChannel(userId, channelId);
        
        Map<String, Object> userState = userVoiceStates.computeIfAbsent(userId, k -> new HashMap<>());
        userState.put("muted", muted);
        userState.put("channelId", channelId);
        
        return userState;
    }
    
    /**
     * Cập nhật trạng thái deafen của user
     * @param userId User ID
     * @param channelId Channel ID
     * @param deafened Trạng thái deafen
     * @return Voice state sau khi cập nhật
     * @throws Exception Nếu user không ở trong channel
     */
    public Map<String, Object> updateDeafenState(Long userId, Long channelId, boolean deafened) throws Exception {
        validateUserInChannel(userId, channelId);
        
        Map<String, Object> userState = userVoiceStates.computeIfAbsent(userId, k -> new HashMap<>());
        userState.put("deafened", deafened);
        userState.put("channelId", channelId);
        
        return userState;
    }
    
    /**
     * Cập nhật trạng thái video của user
     * @param userId User ID
     * @param channelId Channel ID
     * @param videoEnabled Trạng thái video
     * @return Voice state sau khi cập nhật
     * @throws Exception Nếu user không ở trong channel
     */
    public Map<String, Object> updateVideoState(Long userId, Long channelId, boolean videoEnabled) throws Exception {
        validateUserInChannel(userId, channelId);
        
        Map<String, Object> userState = userVoiceStates.computeIfAbsent(userId, k -> new HashMap<>());
        userState.put("videoEnabled", videoEnabled);
        userState.put("channelId", channelId);
        
        return userState;
    }
    
    /**
     * Lấy danh sách users trong voice channel
     * @param channelId Channel ID
     * @return List users với thông tin đầy đủ
     */
    public List<Map<String, Object>> getUsersInChannel(Long channelId) {
        Set<Long> userIds = voiceChannelUsers.get(channelId);
        if (userIds == null || userIds.isEmpty()) {
            return new ArrayList<>();
        }
        
        List<Map<String, Object>> usersList = new ArrayList<>();
        for (Long userId : userIds) {
            userRepository.findById(userId).ifPresent(user -> {
                Map<String, Object> userInfo = buildUserInfo(user, userId);
                usersList.add(userInfo);
            });
        }
        
        return usersList;
    }
    
    /**
     * Kiểm tra user có trong voice channel không
     * @param userId User ID
     * @param channelId Channel ID
     * @return true nếu user ở trong channel
     */
    public boolean isUserInChannel(Long userId, Long channelId) {
        Set<Long> users = voiceChannelUsers.get(channelId);
        return users != null && users.contains(userId);
    }
    
    /**
     * Lấy voice state của user
     * @param userId User ID
     * @return Voice state hoặc null nếu không có
     */
    public Map<String, Object> getUserVoiceState(Long userId) {
        return userVoiceStates.get(userId);
    }
    
    /**
     * Lấy channel ID mà user đang tham gia
     * @param userId User ID
     * @return Channel ID hoặc null
     */
    public Long getUserCurrentChannel(Long userId) {
        Map<String, Object> state = userVoiceStates.get(userId);
        if (state != null) {
            Object channelId = state.get("channelId");
            if (channelId instanceof Number) {
                return ((Number) channelId).longValue();
            }
        }
        return null;
    }
    
    /**
     * Xóa tất cả voice state của user (khi disconnect)
     * @param userId User ID
     */
    public void cleanupUserState(Long userId) {
        Long channelId = getUserCurrentChannel(userId);
        if (channelId != null) {
            leaveVoiceChannel(userId, channelId);
        }
        userVoiceStates.remove(userId);
    }
    
    /**
     * Validate user có trong channel không
     */
    private void validateUserInChannel(Long userId, Long channelId) throws Exception {
        if (!isUserInChannel(userId, channelId)) {
            throw new Exception("Bạn không ở trong voice channel này");
        }
    }
    
    /**
     * Build user info map với voice state
     */
    private Map<String, Object> buildUserInfo(User user, Long userId) {
        Map<String, Object> userInfo = new HashMap<>();
        userInfo.put("id", user.getId());
        userInfo.put("username", user.getUsername());
        userInfo.put("avatarUrl", user.getAvatarUrl() != null ? user.getAvatarUrl() : "");
        
        // Include voice state
        Map<String, Object> state = userVoiceStates.get(userId);
        if (state != null) {
            userInfo.put("muted", state.getOrDefault("muted", false));
            userInfo.put("deafened", state.getOrDefault("deafened", false));
            userInfo.put("videoEnabled", state.getOrDefault("videoEnabled", false));
        } else {
            userInfo.put("muted", false);
            userInfo.put("deafened", false);
            userInfo.put("videoEnabled", false);
        }
        
        return userInfo;
    }
    
    /**
     * Get all users in channel (for internal use)
     */
    public Set<Long> getChannelUserIds(Long channelId) {
        return voiceChannelUsers.getOrDefault(channelId, Collections.emptySet());
    }
}

