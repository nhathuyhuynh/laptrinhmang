package com.megachat.service;

import com.megachat.model.*;
import com.megachat.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ChannelService {

    private final ChannelRepository channelRepository;
    private final ServerRepository serverRepository;
    private final ServerMemberRepository serverMemberRepository;
    private final UserRepository userRepository;

    public ChannelService(ChannelRepository channelRepository,
                         ServerRepository serverRepository,
                         ServerMemberRepository serverMemberRepository,
                         UserRepository userRepository) {
        this.channelRepository = channelRepository;
        this.serverRepository = serverRepository;
        this.serverMemberRepository = serverMemberRepository;
        this.userRepository = userRepository;
    }

    public List<Channel> getServerChannels(Long serverId, Long userId) throws Exception {
        Server server = serverRepository.findById(serverId)
            .orElseThrow(() -> new Exception("Server not found"));

        User user = userRepository.findById(userId)
            .orElseThrow(() -> new Exception("User not found"));

        if (!serverMemberRepository.existsByServerAndUser(server, user)) {
            throw new Exception("You are not a member of this server");
        }

        return channelRepository.findByServerIdOrderByPositionAsc(serverId);
    }

    @Transactional
    public Channel createChannel(Long serverId, Long userId, String name, ChannelType type) throws Exception {
        Server server = serverRepository.findById(serverId)
            .orElseThrow(() -> new Exception("Server not found"));

        User user = userRepository.findById(userId)
            .orElseThrow(() -> new Exception("User not found"));

        // Check if user is owner or member
        if (!server.getOwner().getId().equals(userId) && 
            !serverMemberRepository.existsByServerAndUser(server, user)) {
            throw new Exception("You don't have permission to create channels");
        }

        Channel channel = new Channel();
        channel.setName(name);
        channel.setType(type);
        channel.setServer(server);

        // Verify server is set correctly
        if (channel.getServer() == null || !channel.getServer().getId().equals(serverId)) {
            throw new Exception("Failed to set server for channel");
        }

        // Set position (last position) - only count channels of THIS server
        List<Channel> existingChannels = channelRepository.findByServerIdOrderByPositionAsc(serverId);
        int maxPosition = existingChannels.stream()
            .mapToInt(c -> c.getPosition() != null ? c.getPosition() : 0)
            .max()
            .orElse(-1);
        channel.setPosition(maxPosition + 1);

        Channel savedChannel = channelRepository.save(channel);
        
        // Reload to ensure server relationship is persisted
        savedChannel = channelRepository.findById(savedChannel.getId())
            .orElseThrow(() -> new Exception("Failed to save channel"));
        
        // Verify saved channel has correct server
        if (savedChannel.getServer() == null || !savedChannel.getServer().getId().equals(serverId)) {
            throw new Exception("Channel was saved with incorrect server. Expected: " + serverId + 
                ", Got: " + (savedChannel.getServer() != null ? savedChannel.getServer().getId() : "null"));
        }
        
        System.out.println("Channel created: " + savedChannel.getName() + " for server: " + serverId);
        
        return savedChannel;
    }

    @Transactional
    public Channel updateChannel(Long channelId, Long userId, String name) throws Exception {
        Channel channel = channelRepository.findById(channelId)
            .orElseThrow(() -> new Exception("Channel not found"));

        Server server = channel.getServer();
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new Exception("User not found"));

        // Check if user is owner
        if (!server.getOwner().getId().equals(userId)) {
            throw new Exception("Only server owner can update channels");
        }

        if (name != null && !name.trim().isEmpty()) {
            channel.setName(name.trim());
        }

        return channelRepository.save(channel);
    }

    @Transactional
    public void deleteChannel(Long channelId, Long userId) throws Exception {
        Channel channel = channelRepository.findById(channelId)
            .orElseThrow(() -> new Exception("Channel not found"));

        Server server = channel.getServer();
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new Exception("User not found"));

        // Check if user is owner
        if (!server.getOwner().getId().equals(userId)) {
            throw new Exception("Only server owner can delete channels");
        }

        channelRepository.delete(channel);
    }

    public Channel getChannelById(Long channelId, Long userId) throws Exception {
        Channel channel = channelRepository.findById(channelId)
            .orElseThrow(() -> new Exception("Channel not found"));

        Server server = channel.getServer();
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new Exception("User not found"));

        if (!serverMemberRepository.existsByServerAndUser(server, user)) {
            throw new Exception("You are not a member of this server");
        }

        return channel;
    }
}

