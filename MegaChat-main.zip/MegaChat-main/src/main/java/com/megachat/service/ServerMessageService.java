package com.megachat.service;

import com.megachat.model.*;
import com.megachat.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ServerMessageService {

    private final ServerMessageRepository serverMessageRepository;
    private final ChannelRepository channelRepository;
    private final ServerMemberRepository serverMemberRepository;
    private final UserRepository userRepository;

    public ServerMessageService(ServerMessageRepository serverMessageRepository,
                               ChannelRepository channelRepository,
                               ServerMemberRepository serverMemberRepository,
                               UserRepository userRepository) {
        this.serverMessageRepository = serverMessageRepository;
        this.channelRepository = channelRepository;
        this.serverMemberRepository = serverMemberRepository;
        this.userRepository = userRepository;
    }

    public List<ServerMessage> getChannelMessages(Long channelId, Long userId, Long afterId) throws Exception {
        Channel channel = channelRepository.findById(channelId != null ? channelId : 0L)
            .orElseThrow(() -> new Exception("Channel not found"));

        User user = userRepository.findById(userId != null ? userId : 0L)
            .orElseThrow(() -> new Exception("User not found"));

        // Check if user is member of server
        if (!serverMemberRepository.existsByServerAndUser(channel.getServer(), user)) {
            throw new Exception("You are not a member of this server");
        }

        // Only text channels can have messages
        if (channel.getType() != ChannelType.TEXT) {
            throw new Exception("This channel does not support messages");
        }

        return serverMessageRepository.findByChannelIdOrderByIdAsc(channelId != null ? channelId : 0L, afterId);
    }

    @Transactional
    public ServerMessage sendMessage(Long channelId, Long userId, String content, Long replyToId) throws Exception {
        Channel channel = channelRepository.findById(channelId != null ? channelId : 0L)
            .orElseThrow(() -> new Exception("Channel not found"));

        User user = userRepository.findById(userId != null ? userId : 0L)
            .orElseThrow(() -> new Exception("User not found"));

        // Check if user is member of server
        if (!serverMemberRepository.existsByServerAndUser(channel.getServer(), user)) {
            throw new Exception("You are not a member of this server");
        }

        // Only text channels can have messages
        if (channel.getType() != ChannelType.TEXT) {
            throw new Exception("This channel does not support messages");
        }

        ServerMessage message = new ServerMessage();
        message.setChannel(channel);
        message.setSender(user);
        message.setContent(content);

        // Set replyTo if provided
        if (replyToId != null) {
            ServerMessage replyTo = serverMessageRepository.findById(replyToId)
                .orElseThrow(() -> new Exception("Reply message not found"));
            message.setReplyTo(replyTo);
        }

        return serverMessageRepository.save(message);
    }

    @Transactional
    public ServerMessage sendMessageWithFile(Long channelId, Long userId, String content,
                                            String fileUrl, String fileName, String fileType, Long fileSize, Long replyToId) throws Exception {
        Channel channel = channelRepository.findById(channelId != null ? channelId : 0L)
            .orElseThrow(() -> new Exception("Channel not found"));

        User user = userRepository.findById(userId != null ? userId : 0L)
            .orElseThrow(() -> new Exception("User not found"));

        // Check if user is member of server
        if (!serverMemberRepository.existsByServerAndUser(channel.getServer(), user)) {
            throw new Exception("You are not a member of this server");
        }

        // Only text channels can have messages
        if (channel.getType() != ChannelType.TEXT) {
            throw new Exception("This channel does not support messages");
        }

        ServerMessage message = new ServerMessage();
        message.setChannel(channel);
        message.setSender(user);
        message.setContent(content != null ? content : (fileName != null ? fileName : "Đã gửi file"));
        message.setFileUrl(fileUrl);
        message.setFileName(fileName);
        message.setFileType(fileType);
        message.setFileSize(fileSize);

        // Set replyTo if provided
        if (replyToId != null) {
            ServerMessage replyTo = serverMessageRepository.findById(replyToId)
                .orElseThrow(() -> new Exception("Reply message not found"));
            message.setReplyTo(replyTo);
        }

        return serverMessageRepository.save(message);
    }

    @Transactional
    public ServerMessage editMessage(Long messageId, Long userId, String newContent) throws Exception {
        ServerMessage message = serverMessageRepository.findById(messageId != null ? messageId : 0L)
            .orElseThrow(() -> new Exception("Message not found"));

        // Check if user is the sender
        if (!message.getSender().getId().equals(userId)) {
            throw new Exception("You can only edit your own messages");
        }

        message.setContent(newContent);
        message.setEditedAt(LocalDateTime.now());

        return serverMessageRepository.save(message);
    }

    @Transactional
    public ServerMessage deleteMessage(Long messageId, Long userId) throws Exception {
        ServerMessage message = serverMessageRepository.findById(messageId != null ? messageId : 0L)
            .orElseThrow(() -> new Exception("Message not found"));

        // Check if user is the sender or server owner
        Server server = message.getChannel().getServer();
        if (!message.getSender().getId().equals(userId) && 
            !server.getOwner().getId().equals(userId)) {
            throw new Exception("You don't have permission to delete this message");
        }

        message.setIsDeleted(true);
        return serverMessageRepository.save(message);
    }
}

