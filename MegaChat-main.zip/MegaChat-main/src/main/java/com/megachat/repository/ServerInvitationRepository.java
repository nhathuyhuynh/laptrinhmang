package com.megachat.repository;

import com.megachat.model.ServerInvitation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ServerInvitationRepository extends JpaRepository<ServerInvitation, Long> {
    Optional<ServerInvitation> findByInviteCode(String inviteCode);
    
    @Query("SELECT i FROM ServerInvitation i WHERE i.server.id = :serverId")
    List<ServerInvitation> findByServerId(@Param("serverId") Long serverId);
}

