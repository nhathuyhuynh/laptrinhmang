package com.megachat.repository;

import com.megachat.model.Channel;
import com.megachat.model.ChannelType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ChannelRepository extends JpaRepository<Channel, Long> {
    @Query("SELECT c FROM Channel c WHERE c.server.id = :serverId ORDER BY c.position ASC")
    List<Channel> findByServerIdOrderByPositionAsc(@Param("serverId") Long serverId);
    
    @Query("SELECT c FROM Channel c WHERE c.server.id = :serverId AND c.type = :type ORDER BY c.position ASC")
    List<Channel> findByServerIdAndTypeOrderByPositionAsc(@Param("serverId") Long serverId, @Param("type") ChannelType type);
}

