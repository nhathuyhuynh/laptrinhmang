package com.megachat.repository;

import com.megachat.model.Friendship;
import com.megachat.model.FriendshipStatus;
import com.megachat.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface FriendshipRepository extends JpaRepository<Friendship, Long> {

    // Tìm lời mời đã gửi (outgoing)
    List<Friendship> findByRequesterAndStatus(User requester, FriendshipStatus status);

    // Tìm lời mời đã nhận (incoming)
    List<Friendship> findByReceiverAndStatus(User receiver, FriendshipStatus status);

    // Tìm lời mời theo ID và receiver (để accept/decline)
    Optional<Friendship> findByIdAndReceiver(Long id, User receiver);

    // Tìm tất cả bạn bè đã chấp nhận của một user
    @Query("SELECT f FROM Friendship f " +
           "WHERE (f.requester = :user OR f.receiver = :user) " +
           "AND f.status = 'ACCEPTED'")
    List<Friendship> findAcceptedFriendships(@Param("user") User user);

    // Tìm friendship đã chấp nhận giữa hai user
    @Query("SELECT f FROM Friendship f " +
           "WHERE ((f.requester = :user1 AND f.receiver = :user2) " +
           "OR (f.requester = :user2 AND f.receiver = :user1)) " +
           "AND f.status = 'ACCEPTED'")
    Optional<Friendship> findAcceptedFriendship(
        @Param("user1") User user1,
        @Param("user2") User user2
    );

    // Kiểm tra xem hai user đã là bạn bè chưa (ACCEPTED)
    @Query("SELECT COUNT(f) > 0 FROM Friendship f " +
           "WHERE ((f.requester = :user1 AND f.receiver = :user2) " +
           "OR (f.requester = :user2 AND f.receiver = :user1)) " +
           "AND f.status = 'ACCEPTED'")
    boolean existsAcceptedFriendship(
        @Param("user1") User user1,
        @Param("user2") User user2
    );

    // Tìm friendship bất kỳ giữa hai user (bất kỳ trạng thái nào)
    @Query("SELECT f FROM Friendship f " +
           "WHERE (f.requester = :user1 AND f.receiver = :user2) " +
           "OR (f.requester = :user2 AND f.receiver = :user1)")
    Optional<Friendship> findFriendshipBetweenUsers(
        @Param("user1") User user1,
        @Param("user2") User user2
    );
}
