package com.megachat.repository;

import com.megachat.model.ServerMessage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ServerMessageRepository extends JpaRepository<ServerMessage, Long> {
    
    @Query("SELECT m FROM ServerMessage m WHERE m.channel.id = :channelId " +
           "AND (:afterId IS NULL OR m.id > :afterId) " +
           "ORDER BY m.id ASC")
    List<ServerMessage> findByChannelIdOrderByIdAsc(
        @Param("channelId") Long channelId,
        @Param("afterId") Long afterId
    );
    
    @Query("SELECT m FROM ServerMessage m WHERE m.channel.id = :channelId " +
           "ORDER BY m.id DESC")
    List<ServerMessage> findByChannelIdOrderByIdDesc(@Param("channelId") Long channelId);
}

