package com.megachat.repository;

import com.megachat.model.Server;
import com.megachat.model.ServerMember;
import com.megachat.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ServerMemberRepository extends JpaRepository<ServerMember, Long> {
    Optional<ServerMember> findByServerAndUser(Server server, User user);
    
    boolean existsByServerAndUser(Server server, User user);
    
    List<ServerMember> findByServerId(Long serverId);
    
    List<ServerMember> findByUserId(Long userId);
    
    @Query("SELECT COUNT(sm) FROM ServerMember sm WHERE sm.server.id = :serverId")
    Long countByServerId(@Param("serverId") Long serverId);
}

