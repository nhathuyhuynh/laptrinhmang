package com.megachat.controller;

import com.megachat.dto.FriendRequestDto;
import com.megachat.model.Friendship;
import com.megachat.model.User;
import com.megachat.service.FriendshipService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/friends")
@CrossOrigin(origins = "*", maxAge = 3600)
public class FriendshipController {

    private final FriendshipService friendshipService;

    public FriendshipController(FriendshipService friendshipService) {
        this.friendshipService = friendshipService;
    }

    /**
     * Gửi lời mời kết bạn
     */
    @PostMapping("/requests")
    public ResponseEntity<?> sendRequest(@RequestBody FriendRequestDto dto, HttpSession session) {
        try {
            Long userId = getUserId(session);
            System.out.println("=== CONTROLLER: SEND REQUEST ===");
            System.out.println("User ID from session: " + userId);
            System.out.println("Target username: " + dto.getTargetUsername());
            
            Friendship friendship = friendshipService.sendRequest(userId, dto.getTargetUsername(), dto.getMessage());
            
            System.out.println("Request created successfully with ID: " + friendship.getId());
            
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Đã gửi lời mời kết bạn",
                "requestId", friendship.getId()
            ));
        } catch (Exception e) {
            System.out.println("ERROR in sendRequest: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    /**
     * Lấy danh sách bạn bè
     */
    @GetMapping
    public ResponseEntity<?> listFriends(HttpSession session) {
        try {
            Long userId = getUserId(session);
            List<FriendshipService.UserWithOnlineStatus> friends = 
                friendshipService.getAcceptedFriendsWithOnlineStatus(userId);
            
            List<Map<String, Object>> friendDtos = friends.stream()
                .map(friendStatus -> {
                    User friend = friendStatus.getUser();
                    Map<String, Object> friendMap = new HashMap<>();
                    friendMap.put("id", friend.getId());
                    friendMap.put("username", friend.getUsername());
                    friendMap.put("email", friend.getEmail());
                    friendMap.put("phone", friend.getPhone());
                    friendMap.put("avatarUrl", friend.getAvatarUrl());
                    friendMap.put("chatTheme", friend.getChatTheme());
                    friendMap.put("online", friendStatus.isOnline());
                    friendMap.put("lastSeen", friend.getLastSeen());
                    
                    // Get friendship info for nickname and blocked status
                    try {
                        Friendship friendship = friendshipService.getFriendship(userId, friend.getId());
                        friendMap.put("nickname", friendship.getNickname());
                        friendMap.put("blocked", friendship.getBlocked());
                    } catch (Exception e) {
                        friendMap.put("nickname", null);
                        friendMap.put("blocked", false);
                    }
                    
                    return friendMap;
                })
                .collect(Collectors.toList());

            return ResponseEntity.ok(Map.of(
                "success", true,
                "friends", friendDtos
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    /**
     * Lấy danh sách lời mời kết bạn (incoming và outgoing)
     */
    @GetMapping("/requests")
    public ResponseEntity<?> listRequests(HttpSession session) {
        try {
            Long userId = getUserId(session);
            System.out.println("=== CONTROLLER: LIST REQUESTS ===");
            System.out.println("User ID: " + userId);
            
            List<Friendship> incomingFriendships = friendshipService.getIncomingRequests(userId);
            List<Map<String, Object>> incoming = incomingFriendships.stream()
                .map(friendship -> toRequestMap(friendship, "incoming"))
                .collect(Collectors.toList());

            List<Friendship> outgoingFriendships = friendshipService.getOutgoingRequests(userId);
            List<Map<String, Object>> outgoing = outgoingFriendships.stream()
                .map(friendship -> toRequestMap(friendship, "outgoing"))
                .collect(Collectors.toList());

            System.out.println("Returning " + incoming.size() + " incoming and " + outgoing.size() + " outgoing requests");

            return ResponseEntity.ok(Map.of(
                "success", true,
                "incoming", incoming,
                "outgoing", outgoing
            ));
        } catch (Exception e) {
            System.out.println("ERROR in listRequests: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    /**
     * Chấp nhận lời mời kết bạn
     */
    @PostMapping("/requests/{requestId}/accept")
    public ResponseEntity<?> acceptRequest(@PathVariable Long requestId, HttpSession session) {
        try {
            Long userId = getUserId(session);
            friendshipService.acceptRequest(requestId, userId);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Đã chấp nhận lời mời kết bạn"
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    /**
     * Từ chối lời mời kết bạn
     */
    @PostMapping("/requests/{requestId}/decline")
    public ResponseEntity<?> declineRequest(@PathVariable Long requestId, HttpSession session) {
        try {
            Long userId = getUserId(session);
            friendshipService.declineRequest(requestId, userId);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Đã từ chối lời mời kết bạn"
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    /**
     * Tìm kiếm người dùng
     */
    @GetMapping("/search")
    public ResponseEntity<?> searchUsers(@RequestParam String keyword, HttpSession session) {
        try {
            Long userId = getUserId(session);
            
            if (keyword == null || keyword.trim().isEmpty()) {
                return ResponseEntity.ok(Map.of(
                    "success", true,
                    "users", List.of()
                ));
            }

            List<User> users = friendshipService.searchUsers(keyword.trim(), userId);
            Set<Long> onlineUserIds = com.megachat.websocket.ChatEndpoint.getOnlineUserIds();
            
            List<Map<String, Object>> userDtos = users.stream()
                .map(user -> {
                    Map<String, Object> userMap = new HashMap<>();
                    userMap.put("id", user.getId());
                    userMap.put("username", user.getUsername());
                    userMap.put("email", user.getEmail());
                    userMap.put("phone", user.getPhone());
                    userMap.put("avatarUrl", user.getAvatarUrl());
                    userMap.put("online", onlineUserIds.contains(user.getId()));
                    
                    // Kiểm tra trạng thái kết bạn
                    Optional<Friendship> friendship = friendshipService.getFriendshipStatus(userId, user.getId());
                    if (friendship.isPresent()) {
                        Friendship f = friendship.get();
                        userMap.put("friendshipStatus", f.getStatus().name());
                        userMap.put("friendshipId", f.getId());
                        userMap.put("isRequester", f.getRequester().getId().equals(userId));
                    } else {
                        userMap.put("friendshipStatus", "NONE");
                    }
                    
                    return userMap;
                })
                .collect(Collectors.toList());

            return ResponseEntity.ok(Map.of(
                "success", true,
                "users", userDtos
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    /**
     * Xóa bạn bè
     */
    @DeleteMapping("/{friendId}")
    public ResponseEntity<?> unfriend(@PathVariable Long friendId, HttpSession session) {
        try {
            Long userId = getUserId(session);
            friendshipService.unfriend(userId, friendId);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Đã xóa bạn bè thành công"
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    /**
     * Cập nhật biệt danh
     */
    @PutMapping("/{friendId}/nickname")
    public ResponseEntity<?> updateNickname(@PathVariable Long friendId, 
                                           @RequestBody Map<String, String> request, 
                                           HttpSession session) {
        try {
            Long userId = getUserId(session);
            String nickname = request.get("nickname");
            Friendship friendship = friendshipService.updateNickname(userId, friendId, nickname);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Đã cập nhật biệt danh",
                "nickname", friendship.getNickname() != null ? friendship.getNickname() : ""
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    /**
     * Chặn/bỏ chặn tin nhắn
     */
    @PutMapping("/{friendId}/block")
    public ResponseEntity<?> toggleBlock(@PathVariable Long friendId,
                                        @RequestBody Map<String, Boolean> request,
                                        HttpSession session) {
        try {
            Long userId = getUserId(session);
            Boolean blocked = request.get("blocked");
            if (blocked == null) {
                blocked = true;
            }
            Friendship friendship = friendshipService.toggleBlock(userId, friendId, blocked);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", blocked ? "Đã chặn tin nhắn" : "Đã bỏ chặn tin nhắn",
                "blocked", friendship.getBlocked()
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    /**
     * Lấy thông tin friendship
     */
    @GetMapping("/{friendId}")
    public ResponseEntity<?> getFriendship(@PathVariable Long friendId, HttpSession session) {
        try {
            Long userId = getUserId(session);
            Friendship friendship = friendshipService.getFriendship(userId, friendId);
            Map<String, Object> friendshipMap = new HashMap<>();
            friendshipMap.put("id", friendship.getId());
            friendshipMap.put("nickname", friendship.getNickname());
            friendshipMap.put("blocked", friendship.getBlocked());
            return ResponseEntity.ok(Map.of(
                "success", true,
                "friendship", friendshipMap
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    /**
     * Helper: Convert Friendship to Map
     */
    private Map<String, Object> toRequestMap(Friendship friendship, String direction) {
        Map<String, Object> map = new HashMap<>();
        map.put("id", friendship.getId());
        
        // Requester info
        Map<String, Object> requesterMap = new HashMap<>();
        requesterMap.put("id", friendship.getRequester().getId());
        requesterMap.put("username", friendship.getRequester().getUsername());
        requesterMap.put("email", friendship.getRequester().getEmail());
        requesterMap.put("avatarUrl", friendship.getRequester().getAvatarUrl());
        map.put("requester", requesterMap);
        
        // Receiver info
        Map<String, Object> receiverMap = new HashMap<>();
        receiverMap.put("id", friendship.getReceiver().getId());
        receiverMap.put("username", friendship.getReceiver().getUsername());
        receiverMap.put("email", friendship.getReceiver().getEmail());
        receiverMap.put("avatarUrl", friendship.getReceiver().getAvatarUrl());
        map.put("receiver", receiverMap);
        
        map.put("status", friendship.getStatus().name());
        map.put("message", friendship.getMessage());
        map.put("created_at", friendship.getCreatedAt());
        map.put("responded_at", friendship.getRespondedAt());
        map.put("direction", direction);
        return map;
    }

    /**
     * Helper: Get userId from session
     */
    private Long getUserId(HttpSession session) throws Exception {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) {
            throw new Exception("Bạn cần đăng nhập để thực hiện thao tác này");
        }
        return userId;
    }
}
