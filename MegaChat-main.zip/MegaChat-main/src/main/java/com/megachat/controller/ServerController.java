package com.megachat.controller;

import com.megachat.model.*;
import com.megachat.service.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/servers")
@CrossOrigin(origins = "*", maxAge = 3600)
public class ServerController {

    private final ServerService serverService;
    private final ChannelService channelService;
    private final ServerMessageService serverMessageService;
    private final FileStorageService fileStorageService;
    private final FriendshipService friendshipService;

    public ServerController(ServerService serverService,
                           ChannelService channelService,
                           ServerMessageService serverMessageService,
                           FileStorageService fileStorageService,
                           FriendshipService friendshipService) {
        this.serverService = serverService;
        this.channelService = channelService;
        this.serverMessageService = serverMessageService;
        this.fileStorageService = fileStorageService;
        this.friendshipService = friendshipService;
    }

    @PostMapping
    public ResponseEntity<?> createServer(@RequestBody Map<String, String> body, HttpSession session) {
        try {
            Long userId = getUserId(session);
            String name = body.get("name");
            String description = body.get("description");

            if (name == null || name.trim().isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "Server name is required"
                ));
            }

            Server server = serverService.createServer(userId, name, description);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "server", toServerMap(server)
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    @GetMapping
    public ResponseEntity<?> getUserServers(HttpSession session) {
        try {
            Long userId = getUserId(session);
            List<Server> servers = serverService.getUserServers(userId);
            List<Map<String, Object>> serverList = servers.stream()
                .map(this::toServerMap)
                .collect(Collectors.toList());
            return ResponseEntity.ok(Map.of(
                "success", true,
                "servers", serverList
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    @GetMapping("/{serverId}")
    public ResponseEntity<?> getServer(@PathVariable Long serverId, HttpSession session) {
        try {
            Long userId = getUserId(session);
            Server server = serverService.getServerById(serverId, userId);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "server", toServerMap(server)
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    @PutMapping("/{serverId}")
    public ResponseEntity<?> updateServer(@PathVariable Long serverId,
                                         @RequestBody Map<String, String> body,
                                         HttpSession session) {
        try {
            Long userId = getUserId(session);
            String name = body.get("name");
            String description = body.get("description");
            Server server = serverService.updateServer(serverId, userId, name, description, null);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "server", toServerMap(server)
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    @DeleteMapping("/{serverId}")
    public ResponseEntity<?> deleteServer(@PathVariable Long serverId, HttpSession session) {
        try {
            Long userId = getUserId(session);
            serverService.deleteServer(serverId, userId);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Server deleted successfully"
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    @GetMapping("/{serverId}/members")
    public ResponseEntity<?> getServerMembers(@PathVariable Long serverId, HttpSession session) {
        try {
            Long userId = getUserId(session);
            List<com.megachat.model.User> members = serverService.getServerMembers(serverId, userId);
            List<Map<String, Object>> memberList = members.stream()
                .map(user -> {
                    Map<String, Object> map = new java.util.HashMap<>();
                    map.put("id", user.getId());
                    map.put("username", user.getUsername());
                    map.put("avatarUrl", user.getAvatarUrl() != null ? user.getAvatarUrl() : "");
                    map.put("email", user.getEmail());
                    return map;
                })
                .collect(Collectors.toList());
            return ResponseEntity.ok(Map.of(
                "success", true,
                "members", memberList
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    @PostMapping("/{serverId}/invitations")
    public ResponseEntity<?> createInvitation(@PathVariable Long serverId,
                                              @RequestBody Map<String, Object> body,
                                              HttpSession session) {
        try {
            Long userId = getUserId(session);
            Integer maxUses = body.get("maxUses") != null ? 
                (body.get("maxUses") instanceof Integer ? (Integer) body.get("maxUses") : 
                 Integer.parseInt(body.get("maxUses").toString())) : null;
            Integer expiresInDays = body.get("expiresInDays") != null ?
                (body.get("expiresInDays") instanceof Integer ? (Integer) body.get("expiresInDays") :
                 Integer.parseInt(body.get("expiresInDays").toString())) : null;

            ServerInvitation invitation = serverService.createInvitation(serverId, userId, maxUses, expiresInDays);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "invitation", Map.of(
                    "id", invitation.getId(),
                    "inviteCode", invitation.getInviteCode(),
                    "maxUses", invitation.getMaxUses(),
                    "expiresAt", invitation.getExpiresAt() != null ? invitation.getExpiresAt().toString() : null
                )
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    @PostMapping("/join")
    public ResponseEntity<?> joinServerByInvite(@RequestBody Map<String, String> body, HttpSession session) {
        try {
            Long userId = getUserId(session);
            String inviteCode = body.get("inviteCode");
            if (inviteCode == null || inviteCode.trim().isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "Invite code is required"
                ));
            }
            Server server = serverService.joinServerByInvite(userId, inviteCode.trim());
            return ResponseEntity.ok(Map.of(
                "success", true,
                "server", toServerMap(server)
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    @PostMapping("/{serverId}/leave")
    public ResponseEntity<?> leaveServer(@PathVariable Long serverId, HttpSession session) {
        try {
            Long userId = getUserId(session);
            serverService.leaveServer(serverId, userId);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Left server successfully"
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    @DeleteMapping("/{serverId}/members/{memberId}")
    public ResponseEntity<?> removeMember(@PathVariable Long serverId,
                                         @PathVariable Long memberId,
                                         HttpSession session) {
        try {
            Long userId = getUserId(session);
            serverService.removeMember(serverId, userId, memberId);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Member removed successfully"
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    // Invite friend to server
    @GetMapping("/{serverId}/invite-friends")
    public ResponseEntity<?> getInvitableFriends(@PathVariable Long serverId, HttpSession session) {
        try {
            Long userId = getUserId(session);
            // Verify user is member of server
            serverService.getServerById(serverId, userId);
            
            // Get user's friends
            List<com.megachat.service.FriendshipService.UserWithOnlineStatus> friends = 
                friendshipService.getAcceptedFriendsWithOnlineStatus(userId);
            
            // Get current server members
            List<com.megachat.model.User> members = serverService.getServerMembers(serverId, userId);
            java.util.Set<Long> memberIds = members.stream()
                .map(com.megachat.model.User::getId)
                .collect(java.util.stream.Collectors.toSet());
            
            // Filter out friends who are already members
            List<Map<String, Object>> invitableFriends = friends.stream()
                .filter(f -> !memberIds.contains(f.getUser().getId()))
                .map(f -> {
                    User user = f.getUser();
                    return Map.<String, Object>of(
                        "id", user.getId(),
                        "username", user.getUsername(),
                        "email", user.getEmail(),
                        "avatar", user.getAvatarUrl() != null ? user.getAvatarUrl() : "",
                        "isOnline", f.isOnline()
                    );
                })
                .collect(Collectors.toList());
            
            return ResponseEntity.ok(Map.of(
                "success", true,
                "friends", invitableFriends
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    @PostMapping("/{serverId}/invite-friend")
    public ResponseEntity<?> inviteFriendToServer(@PathVariable Long serverId,
                                                  @RequestBody Map<String, Object> body,
                                                  HttpSession session) {
        try {
            Long userId = getUserId(session);
            Long friendId = Long.parseLong(body.get("friendId").toString());
            
            serverService.inviteFriendToServer(serverId, userId, friendId);
            
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Friend invited successfully"
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    // Channel endpoints
    @GetMapping("/{serverId}/channels")
    public ResponseEntity<?> getServerChannels(@PathVariable Long serverId, HttpSession session) {
        try {
            Long userId = getUserId(session);
            List<Channel> channels = channelService.getServerChannels(serverId, userId);
            List<Map<String, Object>> channelList = channels.stream()
                .map(this::toChannelMap)
                .collect(Collectors.toList());
            return ResponseEntity.ok(Map.of(
                "success", true,
                "channels", channelList
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    @PostMapping("/{serverId}/channels")
    public ResponseEntity<?> createChannel(@PathVariable Long serverId,
                                          @RequestBody Map<String, String> body,
                                          HttpSession session) {
        try {
            Long userId = getUserId(session);
            String name = body.get("name");
            String typeStr = body.get("type");
            
            if (name == null || name.trim().isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "Channel name is required"
                ));
            }

            ChannelType type = ChannelType.TEXT;
            if (typeStr != null) {
                try {
                    type = ChannelType.valueOf(typeStr.toUpperCase());
                } catch (IllegalArgumentException e) {
                    return ResponseEntity.badRequest().body(Map.of(
                        "success", false,
                        "message", "Invalid channel type. Use TEXT or VOICE"
                    ));
                }
            }

            Channel channel = channelService.createChannel(serverId, userId, name, type);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "channel", toChannelMap(channel)
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    @PutMapping("/channels/{channelId}")
    public ResponseEntity<?> updateChannel(@PathVariable Long channelId,
                                          @RequestBody Map<String, String> body,
                                          HttpSession session) {
        try {
            Long userId = getUserId(session);
            String name = body.get("name");
            Channel channel = channelService.updateChannel(channelId, userId, name);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "channel", toChannelMap(channel)
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    @DeleteMapping("/channels/{channelId}")
    public ResponseEntity<?> deleteChannel(@PathVariable Long channelId, HttpSession session) {
        try {
            Long userId = getUserId(session);
            channelService.deleteChannel(channelId, userId);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Channel deleted successfully"
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    // Message endpoints
    @GetMapping("/channels/{channelId}/messages")
    public ResponseEntity<?> getChannelMessages(@PathVariable Long channelId,
                                               @RequestParam(required = false) Long afterId,
                                               HttpSession session) {
        try {
            Long userId = getUserId(session);
            List<ServerMessage> messages = serverMessageService.getChannelMessages(channelId, userId, afterId);
            List<Map<String, Object>> messageList = messages.stream()
                .map(this::toMessageMap)
                .collect(Collectors.toList());
            return ResponseEntity.ok(Map.of(
                "success", true,
                "messages", messageList
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    @PostMapping("/channels/{channelId}/messages")
    public ResponseEntity<?> sendMessage(@PathVariable Long channelId,
                                        @RequestBody Map<String, Object> body,
                                        HttpSession session) {
        try {
            Long userId = getUserId(session);
            String content = (String) body.get("content");
            if (content == null || content.trim().isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "Message content is required"
                ));
            }
            Long replyToId = null;
            if (body.get("replyToId") != null) {
                replyToId = Long.parseLong(body.get("replyToId").toString());
            }
            ServerMessage message = serverMessageService.sendMessage(channelId, userId, content, replyToId);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", toMessageMap(message)
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    @PostMapping("/channels/{channelId}/messages/upload")
    public ResponseEntity<?> uploadFile(@PathVariable Long channelId,
                                       @RequestParam("file") MultipartFile file,
                                       @RequestParam(value = "text", required = false) String text,
                                       @RequestParam(value = "replyToId", required = false) Long replyToId,
                                       HttpSession session) {
        try {
            Long userId = getUserId(session);
            
            String filename = fileStorageService.storeFile(file);
            String fileUrl = "/api/messages/files/" + filename;
            
            String content = text != null && !text.trim().isEmpty() ? text.trim() :
                (file.getOriginalFilename() != null ? file.getOriginalFilename() : "Đã gửi file");
            
            ServerMessage message = serverMessageService.sendMessageWithFile(
                channelId, userId, content, fileUrl,
                file.getOriginalFilename(), file.getContentType(), file.getSize(), replyToId
            );
            
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", toMessageMap(message)
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    @PutMapping("/channels/{channelId}/messages/{messageId}")
    public ResponseEntity<?> editMessage(@PathVariable Long channelId,
                                        @PathVariable Long messageId,
                                        @RequestBody Map<String, String> body,
                                        HttpSession session) {
        try {
            Long userId = getUserId(session);
            String newContent = body.get("content");
            ServerMessage message = serverMessageService.editMessage(messageId, userId, newContent);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", toMessageMap(message)
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    @DeleteMapping("/channels/{channelId}/messages/{messageId}")
    public ResponseEntity<?> deleteMessage(@PathVariable Long channelId,
                                          @PathVariable Long messageId,
                                          HttpSession session) {
        try {
            Long userId = getUserId(session);
            ServerMessage message = serverMessageService.deleteMessage(messageId, userId);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", toMessageMap(message)
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    @PostMapping("/{serverId}/icon")
    public ResponseEntity<?> uploadServerIcon(@PathVariable Long serverId,
                                             @RequestParam("file") MultipartFile file,
                                             HttpSession session) {
        try {
            Long userId = getUserId(session);
            Server server = serverService.getServerById(serverId, userId);
            
            // Check if user is owner
            if (!server.getOwner().getId().equals(userId)) {
                return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "Only server owner can upload icon"
                ));
            }

            // Validate file type (only images)
            String contentType = file.getContentType();
            if (contentType == null || !contentType.startsWith("image/")) {
                return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "Only image files are allowed"
                ));
            }

            // Validate file size (max 5MB)
            if (file.getSize() > 5 * 1024 * 1024) {
                return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "File size must be less than 5MB"
                ));
            }

            String filename = fileStorageService.storeFile(file);
            String fileUrl = "/api/messages/files/" + filename;
            
            server = serverService.updateServer(serverId, userId, server.getName(), server.getDescription(), fileUrl);
            
            return ResponseEntity.ok(Map.of(
                "success", true,
                "server", toServerMap(server)
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    // Helper methods
    private Map<String, Object> toServerMap(Server server) {
        return Map.of(
            "id", server.getId(),
            "name", server.getName(),
            "description", server.getDescription() != null ? server.getDescription() : "",
            "iconUrl", server.getIconUrl() != null ? server.getIconUrl() : "",
            "ownerId", server.getOwner().getId(),
            "createdAt", server.getCreatedAt().toString()
        );
    }

    private Map<String, Object> toChannelMap(Channel channel) {
        return Map.of(
            "id", channel.getId(),
            "name", channel.getName(),
            "type", channel.getType().toString(),
            "serverId", channel.getServer().getId(),
            "position", channel.getPosition() != null ? channel.getPosition() : 0,
            "createdAt", channel.getCreatedAt().toString()
        );
    }

    private Map<String, Object> toMessageMap(ServerMessage message) {
        Map<String, Object> map = new java.util.HashMap<>();
        map.put("id", message.getId());
        map.put("channelId", message.getChannel().getId());
        map.put("senderId", message.getSender().getId());
        map.put("senderUsername", message.getSender().getUsername());
        if (message.getSender().getAvatarUrl() != null) {
            map.put("senderAvatarUrl", message.getSender().getAvatarUrl());
        }
        map.put("content", message.getContent());
        map.put("createdAt", message.getCreatedAt().toString());
        if (message.getEditedAt() != null) {
            map.put("editedAt", message.getEditedAt().toString());
        }
        if (message.getIsDeleted() != null) {
            map.put("isDeleted", message.getIsDeleted());
        }
        if (message.getFileUrl() != null) {
            map.put("fileUrl", message.getFileUrl());
            map.put("fileName", message.getFileName());
            map.put("fileType", message.getFileType());
            map.put("fileSize", message.getFileSize());
        }
        if (message.getReplyTo() != null) {
            Map<String, Object> replyToMap = new java.util.HashMap<>();
            replyToMap.put("id", message.getReplyTo().getId());
            replyToMap.put("senderUsername", message.getReplyTo().getSender().getUsername());
            replyToMap.put("content", message.getReplyTo().getContent());
            map.put("replyTo", replyToMap);
        }
        return map;
    }

    private Long getUserId(HttpSession session) throws Exception {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) {
            throw new Exception("Bạn cần đăng nhập để thực hiện thao tác này");
        }
        return userId;
    }
}

