-- Script để kiểm tra channels và server_id
-- Chạy script này để xem channels có được gán đúng server_id không

-- Xem tất cả channels với server_id
SELECT 
    c.id,
    c.name,
    c.type,
    c.server_id,
    s.name as server_name,
    c.position,
    c.created_at
FROM channels c
LEFT JOIN servers s ON c.server_id = s.id
ORDER BY c.server_id, c.position;

-- Đếm channels theo server
SELECT 
    s.id as server_id,
    s.name as server_name,
    COUNT(c.id) as channel_count
FROM servers s
LEFT JOIN channels c ON s.id = c.server_id
GROUP BY s.id, s.name
ORDER BY s.id;

-- Kiểm tra channels có server_id NULL hoặc không hợp lệ
SELECT 
    c.id,
    c.name,
    c.server_id,
    CASE 
        WHEN c.server_id IS NULL THEN 'NULL server_id'
        WHEN s.id IS NULL THEN 'Invalid server_id'
        ELSE 'OK'
    END as status
FROM channels c
LEFT JOIN servers s ON c.server_id = s.id
WHERE c.server_id IS NULL OR s.id IS NULL;

