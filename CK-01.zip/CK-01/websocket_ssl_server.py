import asyncio
import websockets
import json
from datetime import datetime
import sqlite3
import bleach
import random
import string
from websockets.exceptions import ConnectionClosedOK, ConnectionClosedError

HOST = "0.0.0.0"
PORT = 8765

connected_clients = set()
authenticated_users = {}            # websocket -> {"username": str, "role": str}
rooms = {"default": set()}          # room_name -> set of websockets
room_codes = {}                     # room_code -> room_name
room_owners = {}                    # room_name -> username (chủ phòng, tùy chọn)

def init_db():
    conn = sqlite3.connect("users.db")
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            username TEXT PRIMARY KEY,
            password TEXT NOT NULL,
            role TEXT DEFAULT 'user'
        )
    """)
    c.execute("SELECT 1 FROM users WHERE username = 'admin'")
    if not c.fetchone():
        c.execute("INSERT INTO users (username, password, role) VALUES (?, ?, ?)",
                  ("admin", "admin123", "admin"))
    conn.commit()
    conn.close()

def get_user(username):
    conn = sqlite3.connect("users.db")
    c = conn.cursor()
    c.execute("SELECT username, password, role FROM users WHERE username=?", (username,))
    user = c.fetchone()
    conn.close()
    return user

def register_user(username, password):
    if not username or not password:
        return False, "Thiếu username hoặc password"
    if len(username) < 3 or len(password) < 4:
        return False, "Username ≥ 3 ký tự, password ≥ 4 ký tự"
    
    conn = sqlite3.connect("users.db")
    c = conn.cursor()
    try:
        c.execute("INSERT INTO users (username, password, role) VALUES (?, ?, 'user')",
                  (username, password))
        conn.commit()
        return True, "Đăng ký thành công"
    except sqlite3.IntegrityError:
        return False, "Username đã tồn tại"
    finally:
        conn.close()

async def broadcast(room_name, message_json):
    if room_name not in rooms:
        return
    dead = set()
    for ws in rooms[room_name].copy():  # copy để tránh lỗi khi modify set trong loop
        if ws.state == ws.state.OPEN:   # ← sửa chính ở đây: kiểm tra ws.state == OPEN
            try:
                await ws.send(message_json)
            except Exception as e:
                print(f"[Broadcast error to {ws.remote_address}]: {e}")
                dead.add(ws)
        else:
            dead.add(ws)
    
    # Cleanup dead clients
    for ws in dead:
        rooms[room_name].discard(ws)
        connected_clients.discard(ws)
        authenticated_users.pop(ws, None)

async def handle_client(websocket):
    remote_addr = websocket.remote_address
    print(f"[+] New client: {remote_addr}")

    username = None
    current_room = "default"

    try:
        # GIAI ĐOẠN ĐĂNG NHẬP / ĐĂNG KÝ
        while True:
            try:
                raw = await asyncio.wait_for(websocket.recv(), timeout=60.0)
                data = json.loads(raw)
            except (asyncio.TimeoutError, json.JSONDecodeError, ConnectionClosedError):
                return

            msg_type = data.get("type")

            if msg_type == "register":
                ok, msg = register_user(data.get("username", ""), data.get("password", ""))
                await websocket.send(json.dumps({
                    "type": "register_response",
                    "success": ok,
                    "message": msg
                }))
                continue

            if msg_type == "login":
                user = get_user(data.get("username", ""))
                if user and user[1] == data.get("password", ""):
                    username = user[0]
                    role = user[2]
                    authenticated_users[websocket] = {"username": username, "role": role}

                    await websocket.send(json.dumps({
                        "type": "login_success",
                        "username": username,
                        "role": role
                    }))

                    rooms[current_room].add(websocket)
                    await broadcast(current_room, json.dumps({
                        "type": "system",
                        "message": f"{username} đã tham gia phòng {current_room}",
                        "timestamp": datetime.now().strftime("%H:%M:%S")
                    }))
                    break
                else:
                    await websocket.send(json.dumps({
                        "type": "login_failed",
                        "message": "Sai username hoặc password"
                    }))
                continue

            await websocket.send(json.dumps({"type": "error", "message": "Vui lòng đăng nhập trước"}))

        # ĐÃ ĐĂNG NHẬP - XỬ LÝ CÁC LỆNH
        async for raw_msg in websocket:
            try:
                data = json.loads(raw_msg)
            except json.JSONDecodeError:
                continue

            msg_type = data.get("type")

            # Kiểm tra đã đăng nhập chưa cho mọi lệnh (trừ login/register)
            if websocket not in authenticated_users:
                await websocket.send(json.dumps({"type": "error", "message": "Vui lòng đăng nhập trước"}))
                continue

            if msg_type == "message":
                raw_content = data.get("message", "").strip()
                if not raw_content:
                    continue
                clean_msg = bleach.clean(raw_content, tags=[], strip=True)[:2000]
                msg_data = {
                    "type": "message",
                    "sender": username,
                    "message": clean_msg,
                    "timestamp": datetime.now().strftime("%H:%M:%S")
                }
                await broadcast(current_room, json.dumps(msg_data))

            elif msg_type == "create_room":
                room_name = data.get("room_name", f"Phòng của {username}").strip()[:50]
                if not room_name:
                    room_name = f"Phòng của {username}"

                room_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))

                rooms[room_name] = set([websocket])
                room_codes[room_code] = room_name
                room_owners[room_name] = username

                await websocket.send(json.dumps({
                    "type": "room_created",
                    "room": room_name,
                    "room_code": room_code
                }))
                await websocket.send(json.dumps({
                    "type": "joined_room",
                    "room": room_name
                }))
                current_room = room_name
                print(f"[ROOM] {username} tạo phòng '{room_name}' mã {room_code}")

            elif msg_type == "join_room":
                room_code = data.get("room_code", "").strip()
                if room_code not in room_codes:
                    await websocket.send(json.dumps({
                        "type": "error",
                        "message": "Mã phòng không tồn tại hoặc đã hết hạn"
                    }))
                    continue

                room_name = room_codes[room_code]
                rooms[room_name].add(websocket)
                current_room = room_name

                await websocket.send(json.dumps({
                    "type": "joined_room",
                    "room": room_name
                }))
                await broadcast(room_name, json.dumps({
                    "type": "system",
                    "message": f"{username} đã tham gia phòng {room_name}"
                }))
                print(f"[ROOM] {username} join phòng '{room_name}' qua mã {room_code}")

            else:
                await websocket.send(json.dumps({
                    "type": "error",
                    "message": f"Không hỗ trợ lệnh '{msg_type}'"
                }))

    except Exception as e:
        print(f"[ERROR] {remote_addr}: {type(e).__name__} - {e}")
    finally:
        if username:
            await broadcast(current_room, json.dumps({
                "type": "system",
                "message": f"{username} đã rời phòng"
            }))
        for r in list(rooms):
            rooms[r].discard(websocket)
        authenticated_users.pop(websocket, None)
        print(f"[-] {username or 'Guest'} disconnected")

async def main():
    init_db()
    print(f"Server chạy tại ws://{HOST}:{PORT}")
    async with websockets.serve(handle_client, HOST, PORT):
        await asyncio.Future()

if __name__ == "__main__":
    asyncio.run(main())