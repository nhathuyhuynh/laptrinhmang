﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VD1
{

    internal class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Chúc Tết đến trăm điều như ý.");
        }
    }
}

