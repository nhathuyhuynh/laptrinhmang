package main

import (
	"fmt"
)

func main() {
	fmt.Println("Làm ăn phát tài, vạn sự đại cát.")
}
