x = "Vạn sự"
y = "như"
z = "ý"
print(x, y, z)
