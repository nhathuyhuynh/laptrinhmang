import asyncio
import sys

async def send_message(writer):
    while True:
        message = await asyncio.get_event_loop().run_in_executor(None, sys.stdin.readline)
        message = message.strip()
        if message == '0':
            break
        writer.write((message + '\n').encode('utf-8'))
        await writer.drain()

async def receive_message(reader):
    while True:
        data = await reader.readuntil(b'\n')
        if not data:
            break
        print(f"Nhận: {data.decode('utf-8').strip()}")

async def main():
    reader, writer = await asyncio.open_connection('127.0.0.1', 9999)
    print("Kết nối thành công! Gõ tin nhắn (0 để thoát)")

    send_task = asyncio.create_task(send_message(writer))
    receive_task = asyncio.create_task(receive_message(reader))

    await asyncio.wait([send_task, receive_task], return_when=asyncio.FIRST_COMPLETED)

    writer.close()
    await writer.wait_closed()

if __name__ == "__main__":
    asyncio.run(main())