import asyncio
import time
import socket
import threading

# Asyncio server (từ phần 2)
clients = set()

async def handle_client(reader, writer):
    addr = writer.get_extra_info('peername')
    clients.add(writer)
    try:
        while True:
            data = await reader.read(1024)
            if not data:
                break
            for w in list(clients):
                if w != writer:
                    w.write(data)
                    await w.drain()
    finally:
        clients.remove(writer)
        writer.close()
        await writer.wait_closed()

async def async_server(port=8889):
    server = await asyncio.start_server(handle_client, '127.0.0.1', port)
    async with server:
        await server.serve_forever()

# Threaded blocking server
threaded_clients = set()
clients_lock = threading.Lock()

def threaded_handle_client(conn, addr):
    with clients_lock:
        threaded_clients.add(conn)
    try:
        while True:
            data = conn.recv(1024)
            if not data:
                break
            with clients_lock:
                for c in list(threaded_clients):
                    if c != conn:
                        c.sendall(data)
    finally:
        with clients_lock:
            threaded_clients.remove(conn)
        conn.close()

def threaded_server(port=8890):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(('127.0.0.1', port))
    server.listen()
    while True:
        conn, addr = server.accept()
        threading.Thread(target=threaded_handle_client, args=(conn, addr)).start()

# Client test
async def test_client(port, num_messages=5):
    reader, writer = await asyncio.open_connection('127.0.0.1', port)
    for i in range(num_messages):
        msg = f"Msg {i}\n".encode('utf-8')
        writer.write(msg)
        await writer.drain()
        await reader.readuntil(b'\n')
    writer.close()
    await writer.wait_closed()

async def benchmark(port, num_clients, num_messages):
    start = time.time()
    tasks = [test_client(port, num_messages) for _ in range(num_clients)]
    await asyncio.gather(*tasks)
    end = time.time()
    print(f"Thời gian xử lý {num_clients} client, mỗi {num_messages} msg: {end - start:.2f} giây")

async def run_benchmark():
    # Threaded
    threading.Thread(target=threaded_server, daemon=True).start()
    await asyncio.sleep(1)
    print("Benchmark Threaded:")
    await benchmark(8890, 50, 5)

    # Asyncio
    asyncio.create_task(async_server())
    await asyncio.sleep(1)
    print("Benchmark Asyncio:")
    await benchmark(8889, 50, 5)

if __name__ == "__main__":
    asyncio.run(run_benchmark())