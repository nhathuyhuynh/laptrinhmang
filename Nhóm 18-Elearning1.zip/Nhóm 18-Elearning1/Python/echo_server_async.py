import asyncio

async def handle_echo(reader, writer):
    data = await reader.read(1024)  # Await để đọc bất đồng bộ
    message = data.decode('utf-8')
    addr = writer.get_extra_info('peername')
    print(f"Nhận từ {addr}: {message}")

    writer.write(data)  # Gửi lại
    await writer.drain()  # Await để chắc chắn gửi xong

    print(f"Gửi lại cho {addr}: {message}")
    writer.close()  # Đóng kết nối
    await writer.wait_closed()

async def main():
    server = await asyncio.start_server(handle_echo, '127.0.0.1', 9999)
    addr = server.sockets[0].getsockname()
    print(f"Server đang chạy tại {addr}")

    async with server:
        await server.serve_forever()  # Event loop chạy mãi

if __name__ == "__main__":
    asyncio.run(main())  # Khởi động event loop