import asyncio

clients = set()  # Quản lý danh sách writer

async def handle_client(reader, writer):
    addr = writer.get_extra_info('peername')
    print(f"[SERVER] Kết nối từ {addr}")

    clients.add(writer)

    try:
        while True:
            data = await reader.read(1024)  # Await đọc bất đồng bộ
            if not data:
                break
            message = data.decode('utf-8').strip()
            print(f"[SERVER] Nhận từ {addr}: {message}")

            # Broadcast đến tất cả client khác
            for w in list(clients):
                if w != writer and not w.is_closing():
                    w.write(data)
                    await w.drain()  # Await gửi bất đồng bộ
    except Exception as e:
        print(f"[SERVER] Lỗi với {addr}: {e}")
    finally:
        print(f"[SERVER] Đóng kết nối {addr}")
        if writer in clients:
            clients.remove(writer)
        writer.close()
        await writer.wait_closed()

async def main():
    server = await asyncio.start_server(handle_client, '127.0.0.1', 9999)
    addr = server.sockets[0].getsockname()
    print(f"[SERVER] Đang chạy tại {addr}")

    async with server:
        await server.serve_forever()

if __name__ == "__main__":
    asyncio.run(main())