fn main() {
    let name: &'static str = "hạnh phúc, tấn tài tấn lộc, tấn an khang";
    println!("Chúc gia đình {}!", name);
}
