public class VD4 {
    public static void main(String[] args) throws Exception {
        System.out.println("A new year, new start and way to go. Wish you successful and glorious!");
    }
}
