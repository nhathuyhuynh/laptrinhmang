require("dotenv").config();

const express = require("express");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const db = require("./db");
const response = require("./utils/response");

const app = express();
app.use(cors());
app.use(express.json());

// ================== UPLOAD CONFIG ==================
if (!fs.existsSync("uploads")) {
  fs.mkdirSync("uploads");
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/");
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

const upload = multer({ storage });

// Cho phép truy cập ảnh
app.use("/uploads", express.static("uploads"));

// ================== AUTH MIDDLEWARE ==================
function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader) {
    return response(res, 401, "Không có token");
  }

  try {
    const token = authHeader.split(" ")[1];
    jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch (err) {
    return response(res, 401, "Token không hợp lệ");
  }
}

// ================== LOGIN ==================
app.post("/api/auth/login", (req, res) => {
  const { email, password } = req.body;

  const sql = "SELECT * FROM users WHERE email=? AND password=?";
  db.query(sql, [email, password], (err, rows) => {
    if (err) return response(res, 500, "DB error");

    if (rows.length === 0) {
      return response(res, 401, "Sai email hoặc mật khẩu");
    }

    const token = jwt.sign(
      { email },
      process.env.JWT_SECRET,
      { expiresIn: "1h" }
    );

    return response(res, 200, "Login success", { token });
  });
});

// ================== GET BLOG LIST ==================
app.get("/api/blogs", (req, res) => {
  let sql = "SELECT * FROM blogs";
  const params = [];

  if (req.query.search) {
    sql += " WHERE title LIKE ?";
    params.push(`%${req.query.search}%`);
  }

  if (req.query.sort === "desc") {
    sql += " ORDER BY id DESC";
  } else if (req.query.sort === "asc") {
    sql += " ORDER BY id ASC";
  }

  db.query(sql, params, (err, rows) => {
    if (err) return response(res, 500, "DB error");
    return response(res, 200, "Get blog list success", rows);
  });
});

// ================== CREATE BLOG ==================
app.post(
  "/api/blogs",
  authMiddleware,
  upload.single("image"),
  (req, res) => {
    const { title, content } = req.body;
    const image = req.file ? `/uploads/${req.file.filename}` : null;

    const sql =
      "INSERT INTO blogs (title, content, image) VALUES (?, ?, ?)";

    db.query(sql, [title, content, image], (err, result) => {
      if (err) return response(res, 500, "DB error");

      return response(res, 201, "Create blog success", {
        id: result.insertId,
        title,
        content,
        image,
      });
    });
  }
);

// ================== UPDATE BLOG ==================
app.put(
  "/api/blogs/:id",
  authMiddleware,
  upload.single("image"),
  (req, res) => {
    const { title, content } = req.body;
    const id = req.params.id;
    const newImage = req.file ? `/uploads/${req.file.filename}` : null;

    db.query("SELECT image FROM blogs WHERE id=?", [id], (err, rows) => {
      if (err) return response(res, 500, "DB error");

      const oldImage = rows[0]?.image;

      if (newImage && oldImage) {
        const oldPath = "." + oldImage;
        if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath);
      }

      let sql, params;

      if (newImage) {
        sql = "UPDATE blogs SET title=?, content=?, image=? WHERE id=?";
        params = [title, content, newImage, id];
      } else {
        sql = "UPDATE blogs SET title=?, content=? WHERE id=?";
        params = [title, content, id];
      }

      db.query(sql, params, (err) => {
        if (err) return response(res, 500, "DB error");
        return response(res, 200, "Update blog success");
      });
    });
  }
);

// ================== DELETE BLOG ==================
app.delete("/api/blogs/:id", authMiddleware, (req, res) => {
  const id = req.params.id;

  db.query("SELECT image FROM blogs WHERE id=?", [id], (err, rows) => {
    if (err) return response(res, 500, "DB error");

    if (rows[0]?.image) {
      const filePath = "." + rows[0].image;
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    }

    db.query("DELETE FROM blogs WHERE id=?", [id], (err) => {
      if (err) return response(res, 500, "DB error");
      return response(res, 200, "Delete blog success");
    });
  });
});

// ================== START SERVER ==================
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✅ Backend running at http://localhost:${PORT}`);
});
