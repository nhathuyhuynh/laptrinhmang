import api from "./axiosInstance";

export const getBlogs = (params = {}) => {
  return api.get("/blogs", { params });
};

export const deleteBlog = (id) => {
  return api.delete(`/blogs/${id}`);
};
