import api from "./axiosInstance";

export const getBlogs = (params) =>
  api.get("/blogs", { params });

export const createBlog = (formData) =>
  api.post("/blogs", formData);

export const deleteBlog = (id) =>
  api.delete(`/blogs/${id}`);
