<template>
  <div class="login">
    <h2>Login</h2>

    <form @submit.prevent="handleLogin">
      <input v-model="email" placeholder="Email" />
      <input v-model="password" type="password" placeholder="Password" />
      <button>Login</button>
    </form>

    <p v-if="error" style="color:red">{{ error }}</p>
  </div>
</template>

<script setup>
import { ref } from "vue";
import { useRouter } from "vue-router";
import { loginApi } from "../api/auth";

const email = ref("");
const password = ref("");
const error = ref("");
const router = useRouter();

const handleLogin = async () => {
  try {
    const res = await loginApi({
      email: email.value,
      password: password.value,
    });

    // backend trả về token
    localStorage.setItem("token", res.data.data.token);

    router.push("/");
  } catch (err) {
    error.value = "Login thất bại";
  }
};
</script>
