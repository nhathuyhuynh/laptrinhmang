<template>
  <div>
    <h1>Blog List</h1>

    <!-- 🔍 SEARCH -->
    <input
      v-model="search"
      placeholder="Search by title..."
      @input="load"
    />

    <!-- ↕️ SORT -->
    <select v-model="sort" @change="load">
      <option value="">Sort</option>
      <option value="desc">Newest</option>
      <option value="asc">Oldest</option>
    </select>

    <br /><br />

    <router-link to="/create">➕ Create Blog</router-link>

    <ul>
      <li v-for="blog in blogs" :key="blog.id">
        <h3>{{ blog.title }}</h3>
        <p>{{ blog.content }}</p>

        <!-- 🖼️ IMAGE -->
        <img
          v-if="blog.image"
          :src="BACKEND_URL + blog.image"
          style="max-width: 200px; display: block; margin-bottom: 10px"
        />

        <div>
          <router-link :to="`/edit/${blog.id}`">✏️ Edit</router-link>
          <button @click="remove(blog.id)">❌ Delete</button>
        </div>
      </li>
    </ul>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import { getBlogs, deleteBlog } from "../api/blog";

const blogs = ref([]);
const search = ref("");
const sort = ref("");
const BACKEND_URL = "http://localhost:3000";

const load = async () => {
  const res = await getBlogs({
    search: search.value,
    sort: sort.value,
  });

  blogs.value = res.data.data || [];
};

const remove = async (id) => {
  await deleteBlog(id);
  load();
};

onMounted(load);
</script>
