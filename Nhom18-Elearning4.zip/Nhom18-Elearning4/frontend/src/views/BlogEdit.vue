<template>
  <div>
    <h1>Edit Blog</h1>

    <input v-model="title" />
    <br /><br />

    <textarea v-model="content"></textarea>
    <br /><br />

    <input type="file" @change="onFileChange" />
    <br /><br />

    <button @click="update">Update</button>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import axios from "axios";
import { useRoute, useRouter } from "vue-router";

const route = useRoute();
const router = useRouter();

const title = ref("");
const content = ref("");
const image = ref(null);

onMounted(async () => {
  const res = await axios.get("http://localhost:3000/api/blogs");
  const blog = res.data.data.find(b => b.id == route.params.id);
  title.value = blog.title;
  content.value = blog.content;
});

const onFileChange = (e) => {
  image.value = e.target.files[0];
};

const update = async () => {
  const formData = new FormData();
  formData.append("title", title.value);
  formData.append("content", content.value);
  if (image.value) formData.append("image", image.value);

  await axios.put(
    `http://localhost:3000/api/blogs/${route.params.id}`,
    formData,
    {
      headers: {
        Authorization: "Bearer " + localStorage.getItem("token"),
      },
    }
  );

  alert("Update success");
  router.push("/");
};
</script>
