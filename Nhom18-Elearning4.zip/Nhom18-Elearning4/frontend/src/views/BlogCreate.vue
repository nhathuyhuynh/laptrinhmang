<template>
  <div>
    <h1>Create Blog</h1>

    <input v-model="title" placeholder="Title" />
    <br /><br />

    <textarea v-model="content" placeholder="Content"></textarea>
    <br /><br />

    <input type="file" @change="onFileChange" />
    <br /><br />

    <button @click="create">Create</button>
  </div>
</template>

<script setup>
import { ref } from "vue";
import axios from "axios";
import { useRouter } from "vue-router";

const router = useRouter();

const title = ref("");
const content = ref("");
const image = ref(null);

const onFileChange = (e) => {
  image.value = e.target.files[0];
};

const create = async () => {
  const formData = new FormData();
  formData.append("title", title.value);
  formData.append("content", content.value);
  formData.append("image", image.value);

  await axios.post("http://localhost:3000/api/blogs", formData, {
    headers: {
      Authorization: "Bearer " + localStorage.getItem("token"),
    },
  });

  alert("Create blog success");

  // ✅ DÒNG QUAN TRỌNG BỊ THIẾU
  router.push("/");
};
</script>
