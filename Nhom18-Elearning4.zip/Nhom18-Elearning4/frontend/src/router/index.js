import { createRouter, createWebHistory } from "vue-router";
import Login from "../views/Login.vue";
import BlogList from "../views/BlogList.vue";
import BlogCreate from "../views/BlogCreate.vue";
import BlogEdit from "../views/BlogEdit.vue";
import { authGuard } from "./guards";

const routes = [
  {
    path: "/login",
    name: "Login",
    component: Login,
    meta: { public: true },
  },
  {
    path: "/",
    name: "Home",
    component: BlogList,
    meta: { public: false },
  },
  {
    path: "/create",
    name: "Create",
    component: BlogCreate,
    meta: { public: false },
  },
  {
    path: "/edit/:id",
    name: "Edit",
    component: BlogEdit,
    meta: { public: false },
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

router.beforeEach(authGuard);

export default router;
