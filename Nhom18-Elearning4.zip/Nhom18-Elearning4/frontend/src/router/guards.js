export function authGuard(to, from, next) {
  const token = localStorage.getItem("token");

  if (!to.meta.public && !token) {
    return next("/login");
  }

  if (to.path === "/login" && token) {
    return next("/");
  }

  next();
}
