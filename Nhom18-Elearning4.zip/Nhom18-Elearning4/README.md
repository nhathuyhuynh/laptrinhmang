Blog Project 2025 – Fullstack (Vue 3 + Node.js + MySQL)
Mục tiêu
- Xây dựng ứng dụng Blog đơn giản với các chức năng:
- Đăng nhập (JWT)
- CRUD Blog (Create, Read, Delete)
- Upload ảnh blog
- Search & Sort
- API Public & Private
- Chuẩn hóa Request / Response

Công nghệ sử dụng
Frontend
- Vue 3 + Vite
- Vue Router
- Axios
Backend
- Node.js
- Express
- MySQL
- JWT
- Multer (upload ảnh)

Cấu trúc thư mục
blog-project-2025
├── frontend
│   ├── src
│   │   ├── api
│   │   ├── router
│   │   ├── views
│   │   └── main.js
│   └── package.json
├── backend
│   ├── uploads
│   ├── server.js
│   ├── db.js
│   ├── .env
│   └── package.json
└── README.md

Cài đặt & chạy dự án
1. Backend
cd backend
npm install
node server.js
Backend chạy tại: http://localhost:3000

2. Frontend
npm install
npm run dev
Frontend chạy tại: http://localhost:5173

Tài khoản đăng nhập test
Email: admin@gmail.com
Password: 123456

Danh sách API
- Login: POST /api/auth/login
- Get blog list: GET /api/blogs
- Create blog: POST /api/blogs
Headers: Authorization: Bearer <token>
Body: multipart/form-data
- Delete blog: DELETE /api/blogs/:id

Upload ảnh
- Ảnh được lưu tại: backend/uploads
- Truy cập ảnh: http://localhost:3000/uploads/<filename>

Postman
- File: postman/Blog_Project_2025.postman_collection.json
- Bao gồm:
  - Login
  - Get blog list
  - Create blog (upload image)
  - Update blog
  - Delete blog
